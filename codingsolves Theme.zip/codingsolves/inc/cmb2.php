<?php 

add_action( 'cmb2_init', 'cmb2_add_metabox' );
function cmb2_add_metabox() {

	$prefix = '_codingsove_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'metabox',
		'title'        => __( 'Slider Button', 'cmb2' ),
		'object_types' => array( 'header_slider' ),
		'context'      => 'normal',
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		'name' => __( 'Button Text', 'cmb2' ),
		'id' => $prefix . 'button_text',
		'type' => 'text',
	) );

	$cmb->add_field( array(
		'name' => __( 'Button Url', 'cmb2' ),
		'id' => $prefix . 'button_url',
		'type' => 'text_url',
	) );









}/*




add_action( 'cmb2_init', 'cmb2_add_metaboxt' );
function cmb2_add_metaboxt() {

	$prefix = '_timeanddate_';

	$cmbtd = new_cmb2_box( array(
		'id'           => $prefix . 'metabox',
		'title'        => __( 'Time And Day', 'cmb2' ),
		'object_types' => array( 'header_slider' ),
		'context'      => 'normal',
		'priority'     => 'default',
	) );

	

	$cmbtd->add_field( array(
		'name' => __( 'day', 'cmb2' ),
		'id' => $prefix . 'day_text',
		'type' => 'text',
		
	) );

	$cmbtd->add_field( array(
		'name' => __( 'Star And End time', 'cmb2' ),
		'id' => $prefix . 'time_text',
		'type' => 'text',
		
	) );



}







add_action( 'cmb2_init', 'cmb2_add_metaboxs' );
function cmb2_add_metaboxs() {

	$prefix = '_news_';

	$cmbs = new_cmb2_box( array(
		'id'           => $prefix . 'metabox',
		'title'        => __( 'Social Link', 'cmb2' ),
		'object_types' => array( 'header_slider' ),
		'context'      => 'normal',
		'priority'     => 'default',
	) );

	$cmbs->add_field( array(
		'name' => __( 'Link One Text', 'cmb2' ),
		'id' => $prefix . 'socila_link_one_text',
		'type' => 'text',
	) );

	$cmbs->add_field( array(
		'name' => __( 'Link One Url', 'cmb2' ),
		'id' => $prefix . 'socila_link_one_url',
		'type' => 'text_url',
	) );




	$cmbs->add_field( array(
		'name' => __( 'Link Two Text', 'cmb2' ),
		'id' => $prefix . 'socila_link_two_text',
		'type' => 'text',
	) );

	$cmbs->add_field( array(
		'name' => __( 'Link Two Url', 'cmb2' ),
		'id' => $prefix . 'socila_link_two_url',
		'type' => 'text_url',
	) );




	$cmbs->add_field( array(
		'name' => __( 'Link Three Text', 'cmb2' ),
		'id' => $prefix . 'socila_link_three_text',
		'type' => 'text',
	) );

	$cmbs->add_field( array(
		'name' => __( 'Link One Url', 'cmb2' ),
		'id' => $prefix . 'socila_link_three_url',
		'type' => 'text_url',
	) );





	$cmbs->add_field( array(
		'name' => __( 'Link Four Text', 'cmb2' ),
		'id' => $prefix . 'socila_link_four_text',
		'type' => 'text',
	) );

	$cmbs->add_field( array(
		'name' => __( 'Link Four Url', 'cmb2' ),
		'id' => $prefix . 'socila_link_four_url',
		'type' => 'text_url',
	) );







}*/