
<?php 
get_header();
the_post();
global $wp_query;
?>        <!-- News Section -->
             
<?php// require_once get_template_directory() . '/template-parts/common/header_slider.php'; ?>
<?php if (is_front_page()) {
    $args = array(  
            'post_type' => 'post',
             'post_status' => 'publish',
             'posts_per_page' => 3,
             );
            $posts = new WP_Query( $args );
}else{
    $args = array(  
            'post_type' => 'post',
             'post_status' => 'publish',
             'posts_per_page' => -1,
             );
            $posts = new WP_Query( $args );
} ?>

        
    <?php if (!is_front_page()): ?>        
    
        <!-- Banner Section -->
        <section class="page-banner">
            <div class="image-layer" style="background-image:url(<?php echo get_the_post_thumbnail_url(); ?>);"></div>
            <div class="shape-1"></div>
            <div class="shape-2"></div>
            <div class="banner-inner">
                <div class="auto-container">
                    <div class="inner-container clearfix">
                        <h1>   <?php echo wp_title( $sep = ' ', $display = true,  $seplocation = '' );?></h1>
                        <div class="page-nav">
                            <ul class="bread-crumb clearfix">
                                <li><a href="<?php bloginfo('url'); ?>">Home</a></li>
                                <li class="active"> <?php echo wp_title( $sep = ' ', $display = true,  $seplocation = '' );?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Banner Section -->
        <?php endif ?>





        <!-- Blog Section -->            
        <section class="news-section alt-bg" >
            <div class="auto-container">
                <div class="row clearfix">
                    <?php if ( $posts->have_posts() ) : while ( $posts->have_posts() ) : $posts->the_post(); ?>
                    <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms"
                        data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="image-box">
                                <a href="<?php the_permalink(); ?>"><img src="<?php echo get_the_post_thumbnail_url();?>" alt=""></a>
                            </div>
                            <div class="lower-box">
                                <div class="post-meta">
                                    <ul class="clearfix">
                                        <li><span class="far fa-clock"></span><?php echo get_the_date(); ?></li>
                                        <li><span class="far fa-user-circle"></span> <?php the_author(); ?></li>
                                        <li><span class="far fa-comments"></span> <?php echo get_comments_number($post->ID); ?> Comments</li>

                                    </ul>
                                </div>
                                <h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                <div class="text">Lorem ipsum is simply free text used by copytyping refreshing.</div>
                                <div class="link-box"><a class="theme-btn" href="<?php the_permalink(); ?>"><span
                                            class="flaticon-next-1"></span></a></div>
                            </div>
                        </div>
                    </div>  
                    <?php 

                       endwhile; 
                       endif;
                        wp_reset_postdata();
                       
                    ?>   
                   
                </div>
                <?php if (!is_front_page()): ?>
               <!--   <div class="more-box">
                    <a class="theme-btn btn-style-one" href="blog.html.html">
                        <i class="btn-curve"></i>
                        <span class="btn-title">aLoad more posts</span>
                    </a>
                </div> -->
                <?php endif ?>
            </div>
        </section>

        <?php get_footer();?>