
<?php 
/*
* Template Name: About Us Page
*/
get_header();
the_post();
?>

<!-- aboutUs_Tab -->
    

      
   <?php require_once get_template_directory() . '/template-parts/common/about_us_top_html.php'; ?>
          <!--Agency Section-->







                <?php  
                $args = array(  
                    'post_type' => 'aboutUs_Title',
                    'post_status' => 'publish',
                    'posts_per_page' => 1,
                         );
                    $aboutUs_Title = new WP_Query( $args );
                        ?>
<!--Start Agency Section-->
        <section class="agency-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <!--Left Column-->
                    <div class="left-col col-xl-6 col-lg-12 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="sec-title">
                                <?php if ($aboutUs_Title->have_posts() ) : $aboutUs_Title->the_post(); ?>
                                <h2><?php the_title(); ?><span class="dot">.</span></h2>
                            <?php endif ?>
                            </div>

                            <!--Default Tabs-->
                            <div class="default-tabs tabs-box">

                                <!--Tab Btns-->
                                <ul class="tab-btns tab-buttons clearfix">
                                    <?php $aboutUs_Tab = new WP_Query( array( 'post_type' => 'aboutUs_Tab', 'posts_per_page' => 3 ) ); ?>
                                        <?php 
                                        $counter = 0;
                                        while ( $aboutUs_Tab->have_posts() ) : $aboutUs_Tab->the_post(); 
                                         $counter++;
                                        ?>
                                    <li data-tab="#tab-<?php the_ID(); ?>" class="tab-btn <?=($counter == 1) ? 'active-btn' : ''?>"><span><?php the_title();?></span></li>
                                    <?php endwhile; wp_reset_query(); ?>
                                </ul>

                                <!--Tabs Container-->
                                <div class="tabs-content">
                                        <?php
                                        $counter = 0;
                                         $aboutUs_Tab = new WP_Query( array( 'post_type' => 'aboutUs_Tab', 'posts_per_page' => 3 ) );
                                         while ( $aboutUs_Tab->have_posts() ) : $aboutUs_Tab->the_post();  
                                         $counter++;
                                        ?>
                                    <!--Tab-->
                                    <div class="tab  <?=($counter == 1) ? 'active-tab' : ''?>" id="tab-<?php the_ID(); ?>">
                                        <div class="content">
                                            <div class="text"><?php the_content(); ?></div>
                                        </div>
                                    </div>
                                    <?php endwhile; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php  
                $args = array(  
                    'post_type' => 'aboutUs_Title',
                    'post_status' => 'publish',
                    'posts_per_page' => 1,
                         );
                         $aboutUs_Title = new WP_Query( $args );
                    ?>
                <?php if ($aboutUs_Title->have_posts() ) : $aboutUs_Title->the_post(); ?>
                    <!--Right Column-->
                  <div class="right-col col-xl-6 col-lg-12 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="text"><?php the_title(); ?></div>
                            <div class="featured-block-two clearfix">
                                <div class="image"><img src="images/resource/featured-image-6.jpg" alt=""></div>
                                <div class="text">
                                    <ul>
                            <?php  $group = get_post_meta(get_the_ID(),'title_group',true);  ?>
                            <?php 
                            foreach ($group as $groups): 
                            $list_title = $groups['list_title'];
                           
                            ?>
                                        <li><?php echo esc_html($list_title); ?></li>
                            <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        </div>
                    
                
            </div>
        </section>
        <!--End Agency Section-->
    <?php endif ?>
























        <?php require_once get_template_directory() . '/template-parts/common/team_member_html.php'; ?>
        




    <?php get_footer();?>                                 