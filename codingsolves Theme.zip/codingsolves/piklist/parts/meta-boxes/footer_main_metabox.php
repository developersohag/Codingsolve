<?php 
/*
* Title : Comany Logo
* post Type: footer_main
*/


 piklist('field', array(
    'type' => 'editor',
    'field' => '1s_clm_text',
    'label' => '1st Cloum Description',
    'value' => 'Welcome to our web design agency. Lorem ipsum simply free text dolor sited amet cons cing elit.',
    'description' => '1st Cloum Below Logo', 
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));



 piklist('field', array(
    'type' => 'group',
    'field' => '1s_clm_social_link',
    'label' => '1st Cloum Social link',
    'description' => '1st Cloum Below Description', 
    'add_more' => true,
    'fields'  => array(

       

      array(
      'type' => 'text',
      'field' => 'social_icon_class_name',
      'label' => 'Font Aswome Class Name',      
      'help' => 'CodingSolve Team', 
      'attributes' => array ( 'widefat'
       )
    
      ),
       array(
        'type' => 'url',
        'field' => 'socila_url',
        'label' => 'Url',
        'help' => 'CodingSolve Team', 
        'attributes' => array ( 'widefat'
         )
        
      ),







    )    


  )

);


 piklist('field', array(
    'type' => 'text',
    'field' => '2nd_clm_text',
    'label' => '2nd Cloum Title',
    'value' => 'EXPLORE',
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));


 piklist('field', array(
    'type' => 'text',
    'field' => '3rd_clm_text',
    'label' => '3rd Cloum Title',
    'value' => 'CONTACT',
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));



 piklist('field', array(
    'type' => 'text',
    'field' => '4rt_clm_text',
    'label' => '4rt Cloum Title',
    'value' => 'NEWSLETTER',
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));


 piklist('field', array(
    'type' => 'text',
    'field' => '4rt_clm_office_loction',
    'label' => '4rt Cloum Office Location',
    'value' => '60/A Danmondi , bangladesh',
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));





    piklist('field', array(
    'type' => 'url',
    'field' => 'goolge_Map_url',
    'label' => '4rt Cloum Google Map Url',
    'value' => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14608.039147951962!2d90.36710723036111!3d23.74703040345487!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8b33cffc3fb%3A0x4a826f475fd312af!2sDhanmondi%2C%20Dhaka%201205!5e0!3m2!1sen!2sbd!4v1598341899590!5m2!1sen!2sbd',
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));