<?php 
/*
* Title : Number And Button
* post Type: header_foter
*/

/*piklist('field', array(
  'type' => 'file'
  ,'field' => 'sec_img'
  ,'label' => 'Phone number Image'
));


*/

 piklist('field', array(
    'type' => 'text',
    'field' => 'cont_box_sort_title',
    'label' => 'Sort Title Contact Box',
    'value' => 'NEED Coding Sovle HELP?',
    'description' => 'Sort Title For Contact Box', 
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));



 piklist('field', array(
    'type' => 'editor',
    'field' => 'contact_box_sort_des',
    'label' => 'Sort Description Contact Box',
    'value' => 'Prefer speaking with a human to filling out a form? call corporate office and we will connect you with a team member who can help.',
    'description' => 'Sort Description For Contact Box', 
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));






piklist('field', array(
    'type' => 'text',
    'field' => 'header_text',
    'label' => 'Title For Whatsapp Number',
    'description' => 'Whatsapp  Number', 
    'value' => 'Call Any Time',
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));




  piklist('field', array(
    'type' => 'text',
    'field' => 'phone_number',
    'label' => 'Whatsapp Number',
    'description' => 'This is Phone Number', 
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));


    piklist('field', array(
    'type' => 'text',
    'field' => 'phone_rediract',
    'label' => 'Same Whatsapp Number',
    'description' => 'Use same phone For Whatsapp Number',
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));




    piklist('field', array(
    'type' => 'text',
    'field' => 'skype_id',
    'label' => 'Skpye Id',
    'description' => 'Use Skype Id', 
    'value'       => 'live:.cid.e8901229192e4799',
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));


    piklist('field', array(
    'type' => 'text',
    'field' => 'skype_text',
    'label' => 'Skype Button Text',
    'description' => 'Use Button Text',
    'value'       => 'Start Chat',
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));




  piklist('field', array(
    'type' => 'text',
    'field' => 'email_id',
    'label' => 'Email Id',
    'description' => 'Use Email Id', 
    'value'       => 'codingsolve@gmail.com',
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));


    piklist('field', array(
    'type' => 'text',
    'field' => 'email_text',
    'label' => 'Email Button Text',
    'description' => 'Use Email Button Text',
    'value'       => 'Contact With Email',
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));








 piklist('field', array(
    'type' => 'text',
    'field' => 'footer_text_contatus',
    'label' => 'Contact Us Button Text',
    'description' => 'Top Footer Section Sort Title', 
    'value'     => 'CONTACT WITH US',
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));



 piklist('field', array(
    'type' => 'url',
    'field' => 'footer_butonLink_contatus',
    'label' => 'Contact Page Link',
    'description' => 'Use Contact Page Link For Redirect To Contact Page', 
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));