<?php 
/*
* Title : Slider
* post Type: feedback_slider
*/

 piklist('field', array(
    'type' => 'text',
    'field' => 'subtitle_text',
    'label' => 'Subtitle',
    'description' => 'This is Sub title Text', 
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));


