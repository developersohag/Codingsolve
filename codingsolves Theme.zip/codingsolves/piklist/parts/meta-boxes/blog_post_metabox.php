<?php 
/*
* Title : Blog Post Title
* post Type: post
*/

 piklist('field', array(
    'type' => 'text',
    'field' => 'blog_post_tilte',
    'label' => 'Blog Post Title',
    'description' => 'This is Blog Post Title', 
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     ),

    
  ));


