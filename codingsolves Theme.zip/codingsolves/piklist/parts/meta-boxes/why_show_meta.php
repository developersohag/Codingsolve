<?php 
/*
* Title : Slider
* post Type: all_why_show
*/


/* piklist('field', array(
    'type' => 'url',
    'field' => 'youtube_link',
    'label' => 'Youtube Link',
    'description' => 'This Fild For Youtube Link', 
      'help' => 'CodingSolve Team', 
  ));*/



 piklist('field', array(
    'type' => 'group',
    'field' => 'why_show_group',
    'label' => 'Our show Element',
    'add_more' => true,
    'fields'  => array(

       

      array(
      'type' => 'text',
      'field' => 'why_show_name',
      'label' => 'Title',      
      'help' => 'CodingSolve Team', 
      'attributes' => array ( 'widefat'
       )
    
      ),

      /* array(
        'type' => 'file',
        'field' => 'why_show_image',
        'label' => 'Image',
        'description' => 'This is Service Image', 
        'help' => 'CodingSolve Team', 
        'attributes' => array ( 'widefat'
         )
        
      ),*/


    array(
        'type' => 'text',
      'field' => 'why_show_des',
      'label' => 'Sort Description',
      'help' => 'CodingSolve Team', 
      'attributes' => array ( 'widefat'
       ),
    
  )
  
  
  
  
  
  



    )
    
  ));