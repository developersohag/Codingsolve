<?php 
/*
* Title : About Us Top For Image
* post Type: aboutUs_Title
*/



 piklist('field', array(
    'type' => 'group',
    'field' => 'title_group',
    'label' => 'List Sectoin',
    'add_more' => true,
    'fields'  => array(

       

      array(
      'type' => 'text',
      'field' => 'list_title',
      'label' => 'List Title',      
      'help' => 'CodingSolve Team', 
      'attributes' => array ( 'widefat'
       )
    
      ),


    )
    
  ));