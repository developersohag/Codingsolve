<?php 
/*
* Title : Team Member
* post Type: all_team_member
*/


 piklist('field', array(
    'type' => 'group',
    'field' => 'team_member_details_group',
    'label' => 'Our Team Member',
    'add_more' => true,
    'fields'  => array(

       

      array(
      'type' => 'text',
      'field' => 'member_name',
      'label' => 'Member Name',      
      'help' => 'CodingSolve Team', 
      'attributes' => array ( 'widefat'
       )
    
      ),

      array(
      'type' => 'text',
      'field' => 'job_name',
      'label' => 'Job Name',      
      'help' => 'CodingSolve Team', 
      'attributes' => array ( 'widefat'
       )
    
      ),

       array(
        'type' => 'file',
        'field' => 'sec_img',
        'label' => 'Image',
        'description' => 'This is Service Image', 
        'help' => 'CodingSolve Team', 
        'attributes' => array ( 'widefat'
         )
        
      ),

       array(
        'type' => 'url',
        'field' => 'fb_url',
        'label' => 'Facebook Url',
        'description' => 'Url For Facebook', 
        'help' => 'CodingSolve Team', 
        'attributes' => array ( 'widefat'
         )
        
      ),

       array(
        'type' => 'url',
        'field' => 'tw_url',
        'label' => 'Twitter Url',
        'description' => 'Url For Twitter', 
        'help' => 'CodingSolve Team', 
        'attributes' => array ( 'widefat'
         )
        
      ),


         array(
        'type' => 'url',
        'field' => 'inst_url',
        'label' => 'Instragram Url',
        'description' => 'Url For Instragram', 
        'help' => 'CodingSolve Team', 
        'attributes' => array ( 'widefat'
         )
        
      ),






    )    


  )

);




