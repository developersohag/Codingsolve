<?php 
/*
* Title : Slider
* post Type: post_and_contact
*/





piklist( 'field', array(
    'type'       => 'number',
    'field'      => 'Total_project',
    'label'      => 'Left Side : Complete Project',
    'description' => 'For Totla  Complete Project',
    'value'      => 'Totla Complete Project',
    'help'       => 'CodingSolve Team',
    'attributes' => array( 'class' => 'large-text',
    ),

) );





piklist( 'field', array(
    'type'       => 'text',
    'field'      => 'sort_title',
    'label'      => 'Left Side : Subtitle ',
    'value'        => '[contact-form-7 id="enter you id name" title="entercontact From Er title" html_id="contact-form"]',
    'help'       => 'CodingSolve Team',
    'description' => 'For Complete Project',

    'attributes' => array( 'class' => 'large-text',

      'placeholder' => '[contact-form-7 id="enter you id name" title="contact" html_id="contact-form"]'
    ),



) );




piklist('field', array(
  'type' => 'file'
  ,'field' => 'sec_img'
  ,'label' => 'Left Side : Upload Image ',
  'description' => 'Size  190 by 82 pixels', 
));













piklist( 'field', array(
    'type'       => 'text',
    'field'      => 'contact_form_shortcodee',
    'value'      => '
    <div class="form-group">
                                            <div class="field-inner">
                                                [text* your-name placeholder "Your Name"]
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="field-inner">
                                               [text* your-email placeholder "Email Address"]
                                            </div>
                                        </div>                                        
                                        <div class="form-group">
                                            <div class="field-inner">                                                
                                                    [select selected "Web Design" "Web Development"]                                               
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit"class="wpcf7-form-control wpcf7-submit theme-btn btn-style-one"><i class="btn-curve"></i><span class="btn-title">Send Message</span></button>
                                        </div>

    ',
    'label'      => 'Just Copy Thsn Past Contact Form 7 For Quta',
    'help'       => 'CodingSolve Team',
    'attributes' => array( 'class' => 'large-text',

      'placeholder' => '[contact-form-7 id="Fnter Form id " title="contact" html_id="contact-form"]'
    ),



) );


piklist( 'field', array(
    'type'       => 'text',
    'field'      => 'quta_contat_title',
    'label'      => 'Quta Contact From Heading',
    'value'      => 'Contact Us',
    'help'       => 'CodingSolve Team',
    'attributes' => array( 'class' => 'large-text',
    ),

) );





piklist( 'field', array(
    'type'       => 'text',
    'field'      => 'quta_contact_shortcode',
    'label'      => 'Quta Contact Form Shortcode',
    'value'        => '[contact-form-7 id="enter you id name" title="contact" html_id="contact-form"]',
    'help'       => 'CodingSolve Team',

    'attributes' => array( 'class' => 'large-text',

      'placeholder' => '[contact-form-7 id="enter you id name" title="contact" html_id="contact-form"]'
    ),



) );







