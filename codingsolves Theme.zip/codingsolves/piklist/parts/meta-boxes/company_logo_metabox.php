<?php 
/*
* Title : Comany Logo
* post Type: company_logo
*/


piklist('field', array(
  'type' => 'file'
  ,'field' => 'sec_img'
  ,'label' => 'Company Logo'
));