<?php 
/*
* Title : About Us Top For Image
* post Type: aboutUstop_left
*/



 piklist('field', array(
    'type' => 'group',
    'field' => 'tab_group',
    'label' => 'Tab Sectoin',
    'add_more' => true,
    'fields'  => array(

       

      array(
      'type' => 'text',
      'field' => 'tab_title',
      'label' => 'Title',      
      'help' => 'CodingSolve Team', 
      'attributes' => array ( 'widefat'
       )
    
      ),

    array(
      'type' => 'editor',
      'field' => 'tab_content',
      'label' => 'Description',
      'help' => 'CodingSolve Team', 
      'attributes' => array ( 'widefat'
       ),
    
  )



    )
    
  ));