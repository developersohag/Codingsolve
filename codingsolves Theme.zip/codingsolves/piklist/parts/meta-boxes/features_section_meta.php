<?php 
/*
* Title : Slider
* post Type: features_section
*/


/* piklist('field', array(
    'type' => 'url',
    'field' => 'button_link',
    'label' => 'Button Link',
    'description' => 'This Fild For Button Link', 
      'help' => 'CodingSolve Team', 
  ));
*/


 piklist('field', array(
    'type' => 'group',
    'field' => 'features_section_group',
    'label' => 'This Section Home Page Parallax Feature Section',
    'add_more' => true,
    'fields'  => array(

       array(
        'type' => 'file',
        'field' => 'features_section_image',
        'label' => 'Image',
        'description' => 'This is Service Image', 
        'help' => 'CodingSolve Team', 
        'attributes' => array ( 'widefat'
         )
        
      ), 

      array(
      'type' => 'text',
      'field' => 'features_section_name',
      'label' => 'Title',      
      'help' => 'CodingSolve Team', 
      'attributes' => array ( 'widefat'
       )
    
      ),


    array(
      'type' => 'text',
      'field' => 'features_section_des',
      'label' => 'Sub Title',
      'help' => 'CodingSolve Team', 
      'attributes' => array ( 'widefat'
       ),
    
  )



    )
    
  ));