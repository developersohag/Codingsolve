<?php

/*
 * Title : Contact page
 * post Type: page
 * Template: contact
 */





piklist( 'field', array(
    'type'       => 'text',
    'field'      => 'contact_form_shortcodee',
    'value'      => '


    <div class="row clearfix">
    <div class="form-group col-lg-6 col-md-6 col-sm-12">
        <div class="field-inner">
            [text* your-name placeholder "Your Name"]
        </div>
    </div>
    <div class="form-group col-lg-6 col-md-6 col-sm-12">
        <div class="field-inner">
            [text* your-email placeholder "Email Address"]
        </div>
    </div>
    <div class="form-group col-lg-6 col-md-6 col-sm-12">
        <div class="field-inner">
            [tel* phone placeholder "Phone Number"]
        </div>
    </div>
    <div class="form-group col-lg-6 col-md-6 col-sm-12">
        <div class="field-inner">
            [text your-subject placeholder "Subject"]
        </div>
    </div>
    <div class="form-group col-lg-12 col-md-12 col-sm-12">
        <div class="field-inner">[textarea your-message placeholder "Write Message"]</div>
    </div>
    <div class="form-group col-lg-12 col-md-12 col-sm-12">
        <button type="submit"class="wpcf7-form-control wpcf7-submit theme-btn btn-style-one"><i class="btn-curve"></i><span class="btn-title">Send Message</span></button>
    </div>
</div>


    ',
    'label'      => 'Just Copy Thsn Past Contact Form 7',
    'help'       => 'CodingSolve Team',
    'attributes' => array( 'class' => 'large-text',

      'placeholder' => '[contact-form-7 id="Fnter Form id " title="contact" html_id="contact-form"]'
    ),



) );


piklist( 'field', array(
    'type'       => 'text',
    'field'      => 'contact_page_title',
    'label'      => 'Contact From Heading',
    'value'      => 'Contact Us',
    'help'       => 'CodingSolve Team',
    'attributes' => array( 'class' => 'large-text',
    ),

) );





piklist( 'field', array(
    'type'       => 'text',
    'field'      => 'contact_form_shortcode',
    'label'      => 'Contact Form Shortcode',
    'value'        => '[contact-form-7 id="enter you id name" title="contact" html_id="contact-form"]',
    'help'       => 'CodingSolve Team',

    'attributes' => array( 'class' => 'large-text',

      'placeholder' => '[contact-form-7 id="enter you id name" title="contact" html_id="contact-form"]'
    ),



) );



piklist( 'field', array(
    'type'       => 'text',
    'field'      => 'google_map_title',
    'label'      => 'google Map Heading',
    'value'      => 'Our Location',
    'help'       => 'CodingSolve Team',
    'attributes' => array( 'class' => 'large-text',
    ),

) );

