<?php 
/*
* Title : Slider
* post Type: header_slider
*/

 piklist('field', array(
    'type' => 'text',
    'field' => 'button_text',
    'label' => 'Button Text',
    'description' => 'This is bBtton Text', 
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));


  piklist('field', array(
    'type' => 'url',
    'field' => 'button_url',
    'label' => 'Button Url',
    'description' => 'This is Button Url', 
    'help' => 'CodingSolve Team', 
    'attributes' => array ( 'widefat'
     )
    
  ));

