<?php 
/*
* Template Name: Service Page 
*/

get_header();
the_post();
?>


    

      
        <!-- Banner Section -->
        <section class="page-banner">
            <div class="image-layer" style="background-image:url(<?php echo get_the_post_thumbnail_url(); ?>);"></div>
            <div class="shape-1"></div>
            <div class="shape-2"></div>
            <div class="banner-inner">
                <div class="auto-container">
                    <div class="inner-container clearfix">
                        <h1>    <?php echo wp_title( $sep = ' ', $display = true,  $seplocation = '' );?></h1>
                        <div class="page-nav">
                            <ul class="bread-crumb clearfix">
                                <li><a href="<?php bloginfo('url'); ?>">Home</a></li>
                                <li class="active"> Our All Service</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Banner Section -->
      
   



       <?php require_once get_template_directory() . '/template-parts/common/service_section_html.php'; ?>



    <?php get_footer();?>                                 