<?php

    /*
    Template Name: Contact Page
     */
get_header();
?>
<!-- Banner Section -->
<?php while ( have_posts() ) : the_post(); ?>
  
        <section class="page-banner">
            <div class="image-layer" style="background-image:url(<?php echo get_the_post_thumbnail_url(); ?>);"></div>
            <div class="shape-1"></div>
            <div class="shape-2"></div>
            <div class="banner-inner">
                <div class="auto-container">
                    <div class="inner-container clearfix">
                        <h1>   <?php echo wp_title( $sep = ' ', $display = true,  $seplocation = '' );?></h1>
                        <div class="page-nav">
                            <ul class="bread-crumb clearfix">
                                <li><a href="<?php bloginfo('url'); ?>">Home</a></li>
                                <li class="active"> <?php echo wp_title( $sep = ' ', $display = true,  $seplocation = '' );?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

<section class="contact-section">
    <div class="auto-container">
       
        <?php

            /* $page_title = get_theme_mod( 'contact_page_title', 'Write Us a Message' );
            $contact_shortcode = get_theme_mod( 'contact_page_shortcode' );  */
            $page_title        = get_post_meta( $post->ID, 'contact_page_title', true );
            $contact_shortcode = get_post_meta( $post->ID, 'contact_form_shortcode', true );
            $google_map_title = get_post_meta( $post->ID, 'google_map_title', true );

            

        ?>





        <div class="form-box">
            <div class="sec-title">
                <h2><?php if ( $page_title ) {
                        echo esc_html( $page_title );
                    }?><span class="dot">.</span></h2>
            </div>
            <div class="default-form">
                <?php if ( $contact_shortcode ) {
                        echo do_shortcode( $contact_shortcode );
                }?>
            </div>
        </div>






         <div class="sec-title centered new">
            <h2><?php if ( $google_map_title ) {
                        echo esc_html( $google_map_title );
                    }?><span class="dot">.</span></h2>
        </div>

        

        <?php  
        $args = array(  
            'post_type' => 'footer_main',
             'post_status' => 'publish',
             'posts_per_page' => 1,
             );
            $footer_main = new WP_Query( $args );

        ?>
         <?php if ($footer_main->have_posts() ) : $footer_main->the_post(); ?>
        <div class="map-box">
        <?php $goolge_Map_url = get_post_meta(get_the_ID(),'goolge_Map_url',true);  ?> 
        <?php if ($goolge_Map_url ): ?>
                                                  
        <iframe src=" <?php echo esc_html($goolge_Map_url); ?>" width="1920" height="460" frameborder="0" style=”border:0;” allowfullscreen=”” aria-hidden=”false” tabindex=”0″></iframe>
         <?php endif; ?>
        </div>
    <?php endif; ?>

    </div>
</section>
<?php
    endwhile; //resetting the page loop
    wp_reset_query(); //resetting the page query
    ?>
<?php get_footer();?>