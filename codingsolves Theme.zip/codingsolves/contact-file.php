<div class="row clearfix">
    <div class="form-group col-lg-6 col-md-6 col-sm-12">
        <div class="field-inner">
            [text* your-name placeholder "Your Name"]
        </div>
    </div>
    <div class="form-group col-lg-6 col-md-6 col-sm-12">
        <div class="field-inner">
            [text* your-email placeholder "Email Address"]
        </div>
    </div>
    <div class="form-group col-lg-6 col-md-6 col-sm-12">
        <div class="field-inner">
            [tel* phone placeholder "Phone Number"]
        </div>
    </div>
    <div class="form-group col-lg-6 col-md-6 col-sm-12">
        <div class="field-inner">
            [text your-subject placeholder "Subject"]
        </div>
    </div>
    <div class="form-group col-lg-12 col-md-12 col-sm-12">
        <div class="field-inner">[textarea your-message placeholder "Write Message"]</div>
    </div>
    <div class="form-group col-lg-12 col-md-12 col-sm-12">
        <button type="submit"class="wpcf7-form-control wpcf7-submit theme-btn btn-style-one"><i class="btn-curve"></i><span class="btn-title">Send Message</span></button>
    </div>
</div>


[contact-form-7 id="11" title="contact" html_id="contact-form"]



                                        <div class="form-group">
                                            <div class="field-inner">
                                                [text* your-name placeholder "Your Name"]
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="field-inner">
                                               [text* your-email placeholder "Email Address"]
                                            </div>
                                        </div>                                        
                                        <div class="form-group">
                                            <div class="field-inner">                                                
                                                    [select selected "sdf" "sdfsdf"]                                               
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit"class="wpcf7-form-control wpcf7-submit theme-btn btn-style-one"><i class="btn-curve"></i><span class="btn-title">Send Message</span></button>
                                        </div>