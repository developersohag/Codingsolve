
<?php 

get_header();
?>
<?php require_once get_template_directory() . '/template-parts/common/header_slider.php'; ?>

       
         
         <?php require_once get_template_directory() . '/template-parts/common/count_down_html.php'; ?>
        <!-- End Funfacts Section -->

        <!--Services Section-->
         <?php  require_once get_template_directory() . '/template-parts/common/service_section_html.php'; ?>
    
         
         
         
         <?php require_once get_template_directory() . '/template-parts/common/why_show_html.php'; ?>
        


        <!--Testimonials Section--> 
        <?php require_once get_template_directory() . '/template-parts/common/feed_back_html.php'; ?>       


        <!-- Features Section -->
        <?php require_once get_template_directory() . '/template-parts/common/features_section_html.php'; ?>
        
      
        
        <!-- End Funfacts Section -->
        <?php require_once get_template_directory() . '/template-parts/common/post_and_contat_html.php'; ?>

       
        <!--Start Sponsors Section-->
        <?php require_once get_template_directory() . '/template-parts/common/logo_html.php'; ?>  
        <!--End Sponsors Section-->      

        <!-- Start News Section Main Blog-->                 
              <?php require_once get_template_directory() . '/index.php'; ?>    
        <!--End News Section Main Blog-->     
          










<?php get_footer();?>