          <!--Service Block-->
                        <div class="services">
                    <div class="row clearfix">
                        <!--Service Block-->
                        <div class="service-block-two col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <div class="bottom-curve"></div>
                                <div class="icon-box"><span class="flaticon-vector"></span></div>
                                <h5><a href="#"><?php the_title(); ?></a></h5>
                                <div class="text">Lorem ipsum is are many variations of pass of majority.</div>
                                <div class="link-box"><a href="#"><span class="fa fa-angle-right"></span></a></div>
                            </div>
                        </div>
                        </div>
                        </div>
