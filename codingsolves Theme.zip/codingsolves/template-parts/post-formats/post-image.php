
<div class="sec-title">

                    <!--Title Block-->
                    <div class="row clearfix">
                        <div class="column col-xl-6 col-lg-12 col-md-12 col-sm-12">
                            <h2><?php the_title(); ?><span class="dot">.</span></h2>
                        </div>
                        <div class="column col-xl-6 col-lg-12 col-md-12 col-sm-12">
                            <div class="lower-text">There are many variations of passages of Lorem Ipsum available, but
                                the majority have suffered alteration in some form, by injected humour, or randomised.
                            </div>
                        </div>
                    </div>
                </div>

                    
     
              