
        <?php  
        $args = array(  
            'post_type' => 'company_logo',
             'post_status' => 'publish',
             'posts_per_page' => 1,
             );
            $company_logo = new WP_Query( $args );
            ?>
            <?php if ($company_logo->have_posts() ) : $company_logo->the_post();?>
						


        
<section class="sponsors-section">
            <div class="sponsors-outer">
                <!--Sponsors-->
                <div class="auto-container">
                    <!--Sponsors Carousel-->
                    <div class="sponsors-carousel owl-theme owl-carousel"> 
                        <?php 
	                        $image_ids = get_post_meta($post->ID, 'sec_img'); 
	                        foreach ($image_ids as $image) {
							//$myupload = get_post_meta($image);
						?>
                        <div class="slide-item">
                            <figure class="image-box"><a href="#"><?php echo '<img src="' . wp_get_attachment_url($image) . '"/>'; ?></a></figure>
                        </div>  
                        <?php } ?>                     
                    </div>
                </div>
            </div>
        </section>
        	
        <?php endif ?>
						