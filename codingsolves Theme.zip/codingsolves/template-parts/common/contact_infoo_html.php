 <?php  
                $args = array(  
                'post_type' => 'header_foter',
                'post_status' => 'publish',
                'posts_per_page' => 1,
                    );
                $header_foter = new WP_Query( $args ); 
                ?>
<?php if ($header_foter->have_posts() ) : $header_foter->the_post(); ?>
     <?php  $cont_box_sort_title = get_post_meta(get_the_ID(),"cont_box_sort_title",true); ?>
     <?php  $contact_box_sort_des = get_post_meta(get_the_ID(),"contact_box_sort_des",true); ?>

     <?php  $phone_number = get_post_meta(get_the_ID(),"phone_number",true); ?>
     <?php  $phone_rediract = get_post_meta(get_the_ID(),"phone_rediract",true); ?>

     <?php  $skype_id = get_post_meta(get_the_ID(),"skype_id",true); ?>
     <?php $skype_text  = get_post_meta(get_the_ID(),"skype_text",true); ?>


       <?php  $email_id = get_post_meta(get_the_ID(),"email_id",true); ?>
     <?php  $email_text = get_post_meta(get_the_ID(),"email_text",true); ?>


     

<?php if ($cont_box_sort_title || $contact_box_sort_des|| $phone_number || $skype_id || $skype_text ||  $email_id || $email_text): ?>
    




                            <div class="sidebar-widget call-up">
                                <div class="widget-inner">
                                    <div class="sidebar-title">
                                        <h4><?php echo esc_html($cont_box_sort_title); ?></h4>
                                    </div>
                                    <div class="text"><?php echo esc_html($contact_box_sort_des); ?></div>

                                    <div class="phone "><a href="https://api.whatsapp.com/send?phone=+88<?php echo esc_html($phone_rediract); ?>" target="_blank"><span
                                            class="icon fab fa-whatsapp"></span><?php echo esc_html($phone_rediract); ?></a></div>

                                          
                                  <div class="phone ">
                                    <a href="skype:<?php echo esc_html($skype_id); ?>" target="_blank"><span
                                            class="icon fab fa-skype"></span><?php echo esc_html($skype_text); ?></a>
                                            </div>

                                            <div class="phone ">
                                            <a href="mailto:<?php echo esc_html($email_id); ?>"><span
                                            class="icon fas fa-envelope-open"></span><?php echo esc_html($email_text); ?></a>
                                            </div>
                                </div>
                            </div>
                            <?php endif ?>
                        <?php endif; ?>
