
        <?php  
        $args = array(  
            'post_type' => 'features_section',
             'post_status' => 'publish',
             'posts_per_page' => 1,
             );
            $features_section = new WP_Query( $args );

        ?>
         <?php if ($features_section->have_posts() ) : $features_section->the_post(); ?>
<section class="features-section">
            <div class="image-layer" style="background-image: url(<?php echo get_the_post_thumbnail_url()?>);"></div>
            <div class="auto-container">
                <div class="content-box">
                    <h2> <?php echo the_title(); ?><span>.</span></h2>
                    <div class="features clearfix">
                        <?php  $group = get_post_meta(get_the_ID(),'features_section_group',true);  ?>
                            <?php 
                            foreach ($group as $groups): 
                            $name = $groups['features_section_name'];
                            $des = $groups['features_section_des'];
                            $image = wp_get_attachment_url ($groups['features_section_image'][0]);
                            ?> 
                        <div class="feature-block">
                            <div class="inner">
                                <div class="icon-box"><span class=""><img src="<?php echo $image; ?>"></span></div>
                                <h6><?php echo esc_html($name); ?></h6>
                                <h6><?php echo esc_html($des); ?></h6>
                                
                            </div>
                        </div>
                    <?php endforeach ?>

                </div>
               <!--  <div class="link-box">
                        <a class="theme-btn btn-style-one" href="about.html">
                            <i class="btn-curve"></i>
                            <span class="btn-title">Discover More</span>
                        </a>
                    </div> -->
            </div>
        </section>
    <?php endif ?>
