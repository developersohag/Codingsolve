        <?php  
        $args = array(  
            'post_type' => 'all_team_member',
             'post_status' => 'publish',
             'posts_per_page' => -1,
             );
            $all_team_member = new WP_Query( $args );


        ?>

<?php if ($all_team_member->have_posts() ) : $all_team_member->the_post(); ?>
        <section class="team-section">
            <div class="auto-container">
                <div class="sec-title centered">
                    <h2><?php the_title(); ?><span class="dot">.</span></h2>
                </div>
                <div class="row clearfix">
                    <!--Team-->
                     <?php  $group = get_post_meta(get_the_ID(),'team_member_details_group',true);  ?>
                      <?php// print_r($group); ?>
                            <?php 
                            foreach ($group as $groups): 
                            $name       = $groups['member_name'];
                            $job        = $groups['job_name'];
                            $image        = $groups['sec_img'];
                            $fb_url     = $groups['fb_url'];
                            $tw_url     = $groups['tw_url'];
                            $it_url   = $groups['inst_url'];
                            ?>  
                    <div class="team-block col-lg-4 col-md-6 col-sm-12">
                        <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="image-box">
                                <a href="about.html"><?php echo '<img src="' . wp_get_attachment_url($image[0]) . '"/>'; ?></a>
                                <ul class="social-links clearfix">
                                    <li><a href="<?php echo  esc_html($fb_url) ?> "target="_blank"><span class="fab fa-facebook-square"></span></a></li>
                                    <li><a href="<?php echo  esc_html($tw_url) ?> "target="_blank"><span class="fab fa-twitter"></span></a></li>
                                    <li><a href="<?php echo  esc_html($it_url)?> "target="_blank"><span class="fab fa-instagram"></span></a></li>
                                </ul>
                            </div>

                            
                            <div class="lower-box">
                                <h5><?php echo $name ?></h5>
                                <div class="designation"><?php echo  $job ?></div>
                            </div>
                           
                        </div>
                    </div>
                     <?php endforeach ?>

                   
                </div>
            </div>
        </section>
        <?php endif ?>