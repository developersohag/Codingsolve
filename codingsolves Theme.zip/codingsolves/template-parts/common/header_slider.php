

        <!-- Banner Section -->
        
        <section class="banner-section banner-two">

            <div class="banner-carousel owl-theme owl-carousel">
                <!-- Slide Item -->

                 <?php 
                    $args = array(  
                        'post_type' => 'header_slider',
                        'post_status' => 'publish',
                        'posts_per_page' => -1,
                    );
                    $header_slider = new WP_Query( $args );         
                    while ( $header_slider->have_posts() ) : $header_slider->the_post(); 
                    ?>
                <!-- Slide Item -->
                <div class="slide-item">
                    <div class="image-layer" style="background-image: url(<?php echo get_the_post_thumbnail_url(null, 'large' ); ?>);"></div>
                    <div class="shape-1"></div>
                    <div class="shape-2"></div>
                    <div class="shape-3"></div>
                    <div class="shape-4"></div>
                    <div class="shape-5"></div>
                    <div class="shape-6"></div>
                    <div class="auto-container">
                        <div class="content-box">
                            <div class="content">
                                <div class="inner">
                                    <div class="sub-title"><?php echo get_the_content(); ?></div>
                                    <h1><?php the_title(); ?></h1>
                                    <?php 
                                        $button_text = get_post_meta(get_the_ID(),"button_text",true);
                                        $button_url = get_post_meta(get_the_ID(),"button_url",true);
                                        ?> 
                                        <?php if ($button_text && $button_url): ?>
                                            <div class="link-box">
                                        <a class="theme-btn btn-style-one"  target="_blank" href="<?php echo esc_html($button_url); ?>">
                                            <i class="btn-curve"></i>
                                          <span class="btn-title"><?php echo esc_html($button_text); ?></span>
                                        </a>
                                    </div>
                                        <?php endif ?>
                                    
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
 <?php 
    endwhile;
    wp_reset_postdata(); ?>

            </div>
        </section>
        <!--End Banner Section -->