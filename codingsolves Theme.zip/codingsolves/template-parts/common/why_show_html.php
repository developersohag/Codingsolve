        <?php  
        $args = array(  
            'post_type' => 'all_why_show',
             'post_status' => 'publish',
             'posts_per_page' => 1,
             );
            $all_why_show = new WP_Query( $args );

        ?>
         
 <?php if ($all_why_show->have_posts() ) : $all_why_show->the_post(); ?>
        <section class="why-us-section testimonials-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <!--Left Column-->
                    <div class="left-col col-lg-6 col-md-12 col-sm-12">
                        <div class="inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="round-box">
                                <div class="image-box">
                                    <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="">
                                </div>
                                <?php $youtube_link = get_post_meta(get_the_ID(),'youtube_link',true);  ?>                                
                                <?php if ($youtube_link): ?>
                                    <div class="vid-link">
                                    <a href=" <?php //echo esc_html($youtube_link); ?>" class="lightbox-imagessss">
                                        <div class="icon"><span class="flaticon-play-button-1ssssss"></span><i
                                                class="ripple"></i></div>
                                    </a>
                                </div>
                                <?php endif ;?>                                  
                            </div>
                        </div>
                    </div>
                    <!--Right Column-->
                    <div class="right-col col-lg-6 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="sec-title">
                                <h2><?php the_title(); ?><span class="dot">.</span></h2>
                            </div>                            
                            <div class="features">
                                 <?php  $group = get_post_meta(get_the_ID(),'why_show_group',true);  ?>
                                  <?php 
                            foreach ($group as $groups): 
                            $name = $groups['why_show_name'];
                            $des = $groups['why_show_des'];
                            ?>                                          
                            
                                <div class="feature">
                                    <div class="inner-box">
                                        
                             
                                        <h6> <?php echo esc_html($name); ?></h6>
                                        <div class="text"> <?php echo esc_html($des); ?></div>
                                         
                                    </div>
                                </div> 
                                   <?php endforeach ;?>                            
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endif ?>