         <!-- Funfacts Section -->     
         <?php  
        $args = array(  
            'post_type' => 'count_down',
             'post_status' => 'publish',
              'posts_per_page' => 4,
             );
        $count_down = new WP_Query( $args );  
            if ( $count_down->have_posts() ) :
        ?>   
        <section class="facts-section alternate">
            <div class="auto-container">
                <div class="inner-container">

                    <!-- Fact Counter -->
                    <div class="fact-counter">
                        <div class="row clearfix">
                            <?php                                         
                                while ( $count_down->have_posts() ) : $count_down->the_post(); 
                            ?>
                            <!--Column-->
                            <div class="column counter-column col-lg-3 col-md-6 col-sm-12">
                                <div class="inner">
                                    <div class="content">
                                        <div class="count-outer count-box">
                                           <?php $counddown =get_the_content();?>
                                           
                                                 <span class="count-text" data-speed="4000" data-stop="<?php echo $counddown; ?>">0</span>
                                           
                                        </div>
                                        <div class="counter-title"><?php echo the_title(); ?></div>
                                    </div>
                                </div>
                            </div>
                            <!--Column--> 
                            <?php 
                                endwhile;
                                wp_reset_postdata(); ?>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <?php  endif; ?>
        <!-- End Funfacts Section -->