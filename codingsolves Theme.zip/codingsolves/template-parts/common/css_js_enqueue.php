<?php 
function codingsolve_asset(){

	
	//Add Css And js

	wp_enqueue_style('codingsolve-bootstrapcdn',"https://fonts.googleapis.com/css2?family=Teko:wght@300;400;500;600;700&amp;display=swap");
		
	wp_enqueue_style("codingsolve-bootstrap-css", get_theme_file_uri("assets/css/bootstrap.css"),null,"1.0");	
	wp_enqueue_style("codingsolve-fontawesome-css", get_theme_file_uri("assets/css/fontawesome-all.css"),null,"1.0");
	wp_enqueue_style("codingsolve-awesome-css", get_theme_file_uri("assets/css/owl.css"),null,"1.0");
	wp_enqueue_style("codingsolve-owl-css", get_theme_file_uri("assets/css/flaticon.css"),null,"1.0");
	wp_enqueue_style("codingsolve-animate-css", get_theme_file_uri("assets/css/animate.css"),null,"1.0");
	wp_enqueue_style("codingsolve-jquery-ui-css", get_theme_file_uri("assets/css/jquery-ui.css"),null,"1.0");
	wp_enqueue_style("codingsolve-jquery-fancybox-css", get_theme_file_uri("assets/css/jquery.fancybox.min.css"),null,"1.0");
	wp_enqueue_style("codingsolve-hover-css", get_theme_file_uri("assets/css/hover.css"),null,"1.0");
	wp_enqueue_style("codingsolve-style-css", get_theme_file_uri("assets/css/style.css"),null,"1.0");
	wp_enqueue_style("codingsolve-rtl-css", get_theme_file_uri("assets/css/rtl.css"),null,"1.0");
	wp_enqueue_style("codingsolve-responsive-css", get_theme_file_uri("assets/css/responsive.css"),null,"1.0");
	wp_enqueue_style("codingsolve-color-default-css", get_theme_file_uri("assets/css/colors/color-default.css"),null,"1.0");
	wp_enqueue_style("codingsolve-custom-animate-css", get_theme_file_uri("assets/css/custom-animate.css"),null,"1.0");	
	wp_enqueue_style("codingsolve-wp-style", get_stylesheet_uri(),null,VERSION);
	




	wp_enqueue_script('cookie.js','//cdnjs.cloudflare.com/ajax/libs/js-cookie/2.1.2/js.cookie.min.js',array(),21.0,true);

	wp_enqueue_script("codingsolve-jquery-js", get_theme_file_uri("assets/js/jquery.js"),null,"9.0");
	wp_enqueue_script("codingsolve-popper-js", get_theme_file_uri("assets/js/popper.min.js"),array('jquery'),"1.1.0");
	wp_enqueue_script("codingsolve-bootstrap-js", get_theme_file_uri("assets/js/bootstrap.min.js"),array('jquery'),"1.1.0");
	wp_enqueue_script("codingsolve-TweenMax-js", get_theme_file_uri("assets/js/TweenMax.js"),array('jquery'),"1.1.0");	
	wp_enqueue_script("codingsolve-jquery-ui-js", get_theme_file_uri("assets/js/jquery-ui.js"),array('jquery'),"1.1.0");
	wp_enqueue_script("codingsolve-jquery-fancybox-js", get_theme_file_uri("assets/js/jquery.fancybox.js"),array('jquery'),"1.1.0");
	wp_enqueue_script("codingsolve-owl-js", get_theme_file_uri("assets/js/owl.js"),array('jquery'),"1.1.0");
	wp_enqueue_script("codingsolve-mixitup-js", get_theme_file_uri("assets/js/mixitup.js"),array('jquery'),"1.1.0");
	wp_enqueue_script("codingsolve-appear-js", get_theme_file_uri("assets/js/appear.js"),array('jquery'),"1.1.0");
	wp_enqueue_script("codingsolve-wow-js", get_theme_file_uri("assets/js/wow.js"),array('jquery'),"1.1.0");
	wp_enqueue_script("codingsolve-style-switcher-js", get_theme_file_uri("assets/js/jQuery.style.switcher.min.js"),array('jquery'),"1.1.0");
	wp_enqueue_script("codingsolve-easing-js", get_theme_file_uri("assets/js/jquery.easing.min.js"),array('jquery'),"1.1.0");
	wp_enqueue_script("codingsolve-custom-script-js", get_theme_file_uri("assets/js/custom-script.js"),array('jquery'),"1.1.1");
//	wp_enqueue_script("codingsolve-lang-js", get_theme_file_uri("assets/js/lang.js"),array('jquery'),"1.1.0");
//	wp_enqueue_script("codingsolve-switcher-js", get_theme_file_uri("assets/js/color-switcher.js"),array('jquery'),"1.1.0");
//	wp_enqueue_script("codingsolve-ajaxLoadMore-js", get_theme_file_uri("assets/js/ajaxLoadMore.js"),array('jquery'),"1.1.0");
	
	

	

	//wp_enqueue_script('fb.js','https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v4.0',array(),21.0,true);

	
	


}
add_action("wp_enqueue_scripts","codingsolve_asset");