<?php 

function codinslove_extarcss_forHeader_bannar(){
	if (is_home_page()) {
		 $coddingsovle_humbnail_image = get_the_post_thumbnail_url(null,"large");
		 ?>
		 <style>
		 	.ok{
		 	 background-image: url(<?php echo $coddingsovle_humbnail_image);
		 	}
		 </style>
		 <?php
	}
}
add_action("wp_head","codinslove_extarcss_forHeader_bannar", 10);
// wp_head bolte aken html er Head tage e kaj korbe ay css ta mane External css
// 10 Holo akan Payorate Jar ata upora ba nica thkabe 