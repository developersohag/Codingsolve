 <!--Get Quote Section-->
                 <?php  
                $args = array(  
                'post_type' => 'post_and_contact',
                'post_status' => 'publish',
                'posts_per_page' => -1,
                    );
                $post_and_contact = new WP_Query( $args ); 
                ?>
<?php if ($post_and_contact->have_posts() ) : $post_and_contact->the_post(); ?>
        <section class="get-quote-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <!--Left Column-->
                    <div class="left-col col-xl-8 col-lg-12 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="featured-block clearfix">
                                <div class="image"><img src="<?php echo the_post_thumbnail_url(); ?>" alt=""></div>
                                <h4><?php the_title(); ?></h4>
                                <div class="text"><?php echo get_the_content(); ?></div>
                            </div>
                             <div class="counter">
                                <div class="counter-inner clearfix">
                                    <div class="counter-text">

                                      <?php  $Total_project = get_post_meta(get_the_ID(),"Total_project",true); ?>
                                       <?php  $sort_title = get_post_meta(get_the_ID(),"sort_title",true); ?>
                                       <div class="count-box"><span class="count-text" data-stop="<?php echo  $Total_project; ?>"
                                                data-speed="2500"></span></div>
                                        <div class="counter-title"><?php echo esc_html($sort_title); ?></div>
                                    </div>
                                    <?php 
                                        $image_ids = get_post_meta($post->ID, 'sec_img'); 
                                        foreach ($image_ids as $image) {
                                        //$myupload = get_post_meta($image);
                                            ?>
                                        <?php } ?>  
                                    <div class="counter-image"><?php echo '<img src="' . wp_get_attachment_url($image) . '"/>'; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Right Column-->
                    <div class="right-col col-xl-4 col-lg-12 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="form-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <div class="default-form">
                                    <?php

            /* $page_title = get_theme_mod( 'contact_page_title', 'Write Us a Message' );
            $contact_shortcode = get_theme_mod( 'contact_page_shortcode' );  */
            $quta_contat_title        = get_post_meta( $post->ID, 'quta_contat_title', true );
            $quta_contact_shortcode = get_post_meta( $post->ID, 'quta_contact_shortcode', true );
                                    ?>
                                    <h4><?php if ( $quta_contat_title ) {
                        echo esc_html( $quta_contat_title );
                    }?><span>.</span></h4>                                    
                                   
                                            <?php if ( $quta_contact_shortcode ) {
                                            echo do_shortcode( $quta_contact_shortcode );
                                        }?>
                                       

                                   
                                </div>





                                 <!-- <div class="default-form">
                                    <h4>Get a free quote <span>.</span></h4>
                                    <form method="post" action="http://layerdrops.com/linoorhtml/contact.html">
                                        <div class="form-group">
                                            <div class="field-inner">
                                                <input type="text" name="username" value="" placeholder="Your Name"
                                                    required="">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="field-inner">
                                                <input type="email" name="email" value="" placeholder="Email Address"
                                                    required="">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="field-inner">
                                                <input type="text" name="phone" value="" placeholder="Phone Number"
                                                    required="">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="field-inner">
                                                <select class="custom-select-box">
                                                    <option>Choose Service</option>
                                                    <option>Website Development</option>
                                                    <option>Graphic Designing</option>
                                                    <option>Digital Marketing</option>
                                                    <option>App Development</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <button class="theme-btn btn-style-one">
                                                <i class="btn-curve"></i>
                                                <span class="btn-title">Request a quote</span>
                                            </button>
                                        </div>
                                    </form>
                                </div> -->









































                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
<?php endif;?>