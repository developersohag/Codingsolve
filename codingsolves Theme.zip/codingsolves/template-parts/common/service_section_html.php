        <?php  
        $args = array(  
            'post_type' => 'service_title',
             'post_status' => 'publish',
             'posts_per_page' => 1,
             );
            $service_title = new WP_Query( $args );

        ?>

        <?php 

        if ( is_page_template( 'service.php' ) ) {
            $args = array(  
            'post_type' => 'all_service_section',
             'post_status' => 'publish',
             'posts_per_page' => -1,
             );
            } else {
              $args = array(  
            'post_type' => 'all_service_section',
             'post_status' => 'publish',
             'posts_per_page' => 4,
             );
            }
         ?>



         <?php 
            
            $all_service_section = new WP_Query( $args );   
        ?>
 <?php if ($service_title->have_posts() ) : $service_title->the_post(); ?>
        <section class="services-section-two">       
            <div class="auto-container">
               
                <div class="sec-title">
                    <!--Title Block-->
                    <div class="row clearfix">
                        <div class="column col-xl-6 col-lg-12 col-md-12 col-sm-12">
                            <h2><?php the_title(); ?><span class="dot">.</span></h2>
                        </div>
                        <div class="column col-xl-6 col-lg-12 col-md-12 col-sm-12">
                            <div class="lower-text"> <?php the_content(); ?></div>
                        </div>
                    </div>
                </div>
                <div class="services">
                    <div class="row clearfix">
                        <!--Service Block-->
                        <?php while ( $all_service_section->have_posts() ) : $all_service_section->the_post(); ?>
                    
                        <div class="service-block-two col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <div class="bottom-curve"></div>
                                <a href="<?php the_permalink(); ?>"><div class="icon-box"><span class="flaticon-vectors"></span><?php echo get_the_post_thumbnail(); ?></div></a>
                                <h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                <div class="text"><?php echo wp_trim_words( get_the_content(), 10, "..." ); ?> <?php //echo get_the_content(); ?></div>
                                <div class="link-box"><a href="<?php the_permalink(); ?>"><span class="fa fa-angle-right"></span></a></div>
                            </div>
                        </div>
                    <?php  endwhile; wp_reset_postdata(); ?>

                      

                    </div>
                </div>
               
            </div>
        </section>

<?php endif ?>

















