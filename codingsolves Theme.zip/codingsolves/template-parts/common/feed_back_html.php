
        <?php  
        $args = array(  
            'post_type' => 'feedback_title',
             'post_status' => 'publish',
             'posts_per_page' => 1,
             );
            $feedback_title = new WP_Query( $args );

            $args = array(  
            'post_type' => 'feedback_slider',
             'post_status' => 'publish',
             'feedback_slider' => -1,
             );
            $feedback_slider = new WP_Query( $args );

        ?>
        <?php if ($feedback_title->have_posts() ) : $feedback_title->the_post(); ?>
<section class="testimonials-section">
            <div class="auto-container">
                <div class="sec-title">
                    <h2><?php the_title(); ?><span class="dot">.</span></h2>
                </div>
                <div class="carousel-box">
                    <div class="testimonials-carousel owl-theme owl-carousel">
                        <?php 
                    $args = array(  
                        'post_type' => 'feedback_slider',
                        'post_status' => 'publish',
                        'posts_per_page' => -1,
                    );
                    $feedback_slider = new WP_Query( $args );         
                    while ( $feedback_slider->have_posts() ) : $feedback_slider->the_post(); 
                    ?>
                        <div class="testi-block">
                            <div class="inner">
                                <div class="icon"><span>“</span></div>
                                <div class="info">
                                    <div class="image"><a href="team.html"><img src="<?php echo get_the_post_thumbnail_url(); ?>"
                                                alt=""></a></div>
                                    <div class="name"><?php the_title(); ?></div>
                                    <?php  $subtitle_text = get_post_meta(get_the_ID(),"subtitle_text",true); ?>
                                    <div class="designation"><?php echo esc_html($subtitle_text); ?></div>
                                </div>
                                <div class="text"><?php echo get_the_content(); ?></div>
                            </div>
                        </div>
                    <?php endwhile; wp_reset_postdata(); ?>
                        
                       
                    </div>
                </div>
            </div>
        </section>
        <?php endif ?>