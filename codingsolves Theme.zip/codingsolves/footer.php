
       <?php  
                $args = array(  
                    'post_type' => 'header_foter',
                    'post_status' => 'publish',
                    'posts_per_page' => 1,
                         );
                    $header_foter = new WP_Query( $args );
                        ?>


        <!-- Call To Section -->
        <section class="call-to-section">
            <div class="auto-container">
                <div class="inner clearfix">
                    <div class="shape-1 wow slideInRight" data-wow-delay="0ms" data-wow-duration="1500ms"></div>
                    <div class="shape-2 wow fadeInDown" data-wow-delay="0ms" data-wow-duration="1500ms"></div>
                    <?php if ($header_foter->have_posts() ) : $header_foter->the_post(); ?>
                       <h2><?php the_title(); ?></h2>
                       <?php 
                         $footer_text_contatus = get_post_meta(get_the_ID(),"footer_text_contatus",true);
                          $footer_butonLink_contatus = get_post_meta(get_the_ID(),"footer_butonLink_contatus",true);
                           ?> 
                        <?php if ($footer_text_contatus && $footer_butonLink_contatus): ?>
                
                    <div class="link-box">
                        <a class="theme-btn btn-style-two" href="<?php echo $footer_butonLink_contatus; ?>" target="_blank">
                            <i class="btn-curve"></i>
                            <span class="btn-title"><?php echo $footer_text_contatus; ?></span>
                        </a>
                      
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </section>

      <?php  
        $args = array(  
            'post_type' => 'footer_main',
             'post_status' => 'publish',
             'posts_per_page' => 1,
             );
            $footer_main = new WP_Query( $args );

        ?>         
 <?php if ($footer_main->have_posts() ) : $footer_main->the_post(); ?>
   <footer class="main-footer normal-padding">
            <div class="auto-container">
                <!--Widgets Section-->
                <div class="widgets-section">
                    <div class="row clearfix">

                        <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget logo-widget">
                                <div class="widget-content">
                                    <div class="logo">
                                        <a href="<?php bloginfo( 'url' );?>"><img id="fLogo" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="" /></a>
                                    </div>
                                     <?php $fsts_clm_texts = get_post_meta(get_the_ID(),'1s_clm_text',true);  ?> 
                                     <?php if ($fsts_clm_texts ): ?>
                                          <div class="text"><?php echo esc_html($fsts_clm_texts); ?></div>
                                     <?php endif ?>
                                   
                                    <ul class="social-links clearfix">
                            <?php  $group = get_post_meta(get_the_ID(),'1s_clm_social_link',true);  ?>
                            <?php 
                            foreach ($group as $groups): 
                            $clasa_name = $groups['social_icon_class_name'];
                            $url = $groups['socila_url'];
                            ?>     <?php if ($group ): ?>
                             <li><a href="<?php echo esc_html($url); ?>"><span class="<?php echo esc_html($clasa_name); ?>"></span></a></li>
                                 
                             <?php endif ?>
                            <?php endforeach; ?>       
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget links-widget">
                                <div class="widget-content">
                                    <?php $snd_clm_text = get_post_meta(get_the_ID(),'2nd_clm_text',true);  ?> 
                                     <?php if ($snd_clm_text ): ?>
                                    <h6><?php echo esc_html($snd_clm_text); ?></h6>
                                    <?php endif ?>
                                     <?php  wp_nav_menu(array(
                                            'theme_locaton' => 'foterpmenu',
                                            'menu_class'=> 'navigation clearfix',
                                     ));
                                    ?>                         
                                </div>
                            </div>
                        </div>

                        <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget info-widget">
                                <div class="widget-content">
                                    <?php $trd_clm_text = get_post_meta(get_the_ID(),'3rd_clm_text',true);  ?> 
                                     <?php if ($trd_clm_text ): ?>
                                    <h6><?php echo esc_html($trd_clm_text); ?></h6>
                                    <?php endif ?>
                                </div>
                            </div>

                             <?php  $phone_number = get_post_meta(get_the_ID(),"phone_number",true); ?>
                             <?php  $phone_rediract = get_post_meta(get_the_ID(),"phone_rediract",true); ?>
                        
                             <?php  $skype_id = get_post_meta(get_the_ID(),"skype_id",true); ?>
                             <?php $skype_text  = get_post_meta(get_the_ID(),"skype_text",true); ?>
                        
                        
                               <?php  $email_id = get_post_meta(get_the_ID(),"email_id",true); ?>
                             <?php  $email_text = get_post_meta(get_the_ID(),"email_text",true); ?>
                            <div class="sidebar-widget call-up">
                                <div class="widget-inner">
                                    <div class="phone new_clsss"><a href="https://api.whatsapp.com/send?phone=+88<?php echo esc_html($phone_rediract); ?>" target="_blank"><span
                                            class="icon fab fa-whatsapp"></span><?php echo esc_html($phone_number); ?></a></div>

                                          
                                  <div class="phone new_clsss">
                                    <a href="skype:<?php echo esc_html($skype_id); ?>" target="_blank"><span
                                            class="icon fab fa-skype"></span><?php echo esc_html($skype_text); ?></a>
                                            </div>

                                            <div class="phone new_clsss">
                                            <a href="mailto:<?php echo esc_html($email_id); ?>"><span
                                            class="icon fas fa-envelope-open"></span><?php echo esc_html($email_text); ?></a>
                                        </div>
                                    </div>
                                </div>
                        </div>
                   
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        


                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget info-widget">
                                <div class="widget-content">
                                    <?php $frd_clm_text = get_post_meta(get_the_ID(),'4rt_clm_text',true);  ?> 
                                     <?php if ($frd_clm_text ): ?>
                                    <h6><?php echo esc_html($frd_clm_text); ?></h6>

                                    <?php endif ?>
                                    <?php $frt_clm_office_loction = get_post_meta(get_the_ID(),'4rt_clm_office_loction',true);  ?> 
                                     <?php if ($frt_clm_office_loction ): ?>
                                    <ul class="contact-info">
                                        <li class="address"><span class="icon flaticon-pin-1"></span> <?php echo esc_html($frt_clm_office_loction); ?></li>
                                       
                                    </ul>
                                     <?php endif; ?>
                                     <?php $goolge_Map_url = get_post_meta(get_the_ID(),'goolge_Map_url',true);  ?> 
                                     <?php if ($goolge_Map_url ): ?>
                                         
                                <div class="map-box">
                   <iframe src=" <?php echo esc_html($goolge_Map_url); ?>" width="250" height="150" frameborder="0" style=”border:0;” allowfullscreen=”” aria-hidden=”false” tabindex=”0″></iframe>
                </div>
                                     <?php endif; ?>


                                   
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>

       
            <!-- Footer Bottom -->
            <div class="footer-bottom">
                <div class="auto-container">
                    <div class="inner clearfix">
                        <div class="copyright">&copy; copyright <?php echo  date("Y"); ?> by CodingSovle Team Member</div>
                    </div>
                </div>
            </div>

        </footer>
    <?php endif; ?>

    </div>
    <!--End pagewrapper-->

    <a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fa fa-angle-up"></i></a>

      <?php wp_footer();?>
</body>

</html>