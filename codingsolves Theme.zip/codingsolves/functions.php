<?php 	
require_once get_template_directory() . '/inc/tgm.php';
if (site_url()=="http://localhost/codingsolves") {
	define("VERSION",time());
}else{
	define ("VERSION",wp_get_theme()->get("Version"));
}

function codingsolve_theme_setup(){
	load_theme_textdomain("codingsolve_textd");
	add_theme_support( 'post-thumbnails');
	add_theme_support("title_tag");
	add_theme_support("html5" ,array('search-form' , 'comment-list' ));
	add_theme_support("post-formats", array("quote","image"));
	register_nav_menu("topmenu",__("Header Menu","codingsolvetextd"));
	register_nav_menu("foterpmenu",__("Footer Menu","codingsolvetextd"));

	$codingsolve_logo_image_size = array(
		"max-width" => '100',
	    "max-height" =>  '34'
		);
	add_theme_support("custom-logo", $codingsolve_logo_image_size);	


}
add_action("after_setup_theme","codingsolve_theme_setup");

register_post_type(
		'service_section',
		array(
		   'supports' => array(
			  'post-formats'
		   )
		)
);



 
function modify_archive_title( $title ) {
         
    $var = "Our Service";
 
    return $var;
 
}
add_filter( 'get_the_archive_title', 'modify_archive_title', 10, 1 );

function wpse25797_the_archives_link() {
    $archive_page = get_pages(
        array(
            'meta_key' => '_wp_page_template',
            'meta_value' => 'template-service.php'
        )
    );
    $archive_id = $showcase_page[0]->ID;
    echo get_permalink( $archive_id );
}



/*add_action('rest_api_init', 'custom_api_get_projects');
function custom_api_get_projects(){
  register_rest_route( 'all_service_section', '/all-posts', array(
    'methods' => 'GET',
    'callback' => 'custom_api_get_projects_callback'
  ));
}
*/


function cd_widget_one(){
	register_sidebar (array(
	'name'	=> __('Footer Widget One', 'codingsolvetextd'),
	'id'				=> 	'footer_one',
	'descritiop'		=>	__("This is Footer Frist section", "codingsolvetextd"),
	'class'				=> '',
	"before_widget"		=> "<div>",
	"after_widget"		=> "</div>",
	"before_title"		=> " <h6>",
	"after_title"		=> "</h6>",
	"before_titles"		=> " <h6'>",
	"after_titles"		=> "</h6>",
	));


}
add_action("widgets_init","cd_widget_one");





function cd_widget_two(){
	register_sidebar (array(
	'name'	=> __('Footer Widget Two', 'codingsolvetextd'),
	'id'				=> 	'footer_two',
	'descritiop'		=>	__("This is Footer Secend Section", "codingsolvetextd"),
	'class'				=> '',
	"before_widget"		=> "<div>",
	"after_widget"		=> "</div>",
	"before_title"		=> " <h6>",
	"after_title"		=> "</h6>",
	"before_titles"		=> " <h6'>",
	"after_titles"		=> "</h6>",
	));


}
add_action("widgets_init","cd_widget_two");




function cd_cd_footer_three(){
	register_sidebar (array(
	'name'	=> __('Footer Widget Three', 'codingsolvetextd'),
	'id'				=> 	'footer_three',
	'descritiop'		=>	__("This is Three Section", "codingsolvetextd"),
	'class'				=> '',
	"before_widget"		=> "  <div>",
	"after_widget"		=> "</div>",
	"before_title"		=> " <h6>",
	"after_title"		=> "</h6>",
	"before_titles"		=> " <h6'>",
	"after_titles"		=> "</h6>",
	));


}
add_action("widgets_init","cd_cd_footer_three");



function cd_widget_four(){
	register_sidebar (array(
	'name'	=> __('Footer Widget Four', 'codingsolvetextd'),
	'id'				=> 	'footer_four',
	'descritiop'		=>	__("This is Fourth Section", "codingsolvetextd"),
	'class'				=> '',
	"before_widget"		=> "  <div>",
	"after_widget"		=> "</div>",
	"before_title"		=> " <h6>",
	"after_title"		=> "</h6>",
	"before_titles"		=> " <h6'>",
	"after_titles"		=> "</h6>",
	));


}
add_action("widgets_init","cd_widget_four");










//Css And Js
require_once get_template_directory() . '/template-parts/common/css_js_enqueue.php';
//Extar File
require_once get_template_directory() . '/inc/class-wp-bootstrap-navwalker.php';
require_once get_template_directory() . '/inc/tgm.php';
require_once get_template_directory() . '/inc/cmb2.php';
require_once get_template_directory() . '/inc/social-iocn-widget.php';
require_once get_template_directory() . '/inc/contactinfo-widget.php';





//Custom Post
require_once get_template_directory() . '/All_Custom_Post/slider_Custom_post.php';
require_once get_template_directory() . '/All_Custom_Post/countdown_custom_post.php';
require_once get_template_directory() . '/All_Custom_Post/service_seciton.php';
require_once get_template_directory() . '/All_Custom_Post/service_title_Custom_post.php';
require_once get_template_directory() . '/All_Custom_Post/why_show.php';
require_once get_template_directory() . '/All_Custom_Post/features_section_custom_post.php';
require_once get_template_directory() . '/All_Custom_Post/Testimonial_Slider_Title_Cutom_post.php';
require_once get_template_directory() . '/All_Custom_Post/Testimonial_Slider_custom_post.php';
require_once get_template_directory() . '/All_Custom_Post/company_logo.php';
require_once get_template_directory() . '/All_Custom_Post/team_member_custom_post.php';
require_once get_template_directory() . '/All_Custom_Post/about_us_tab.php';
require_once get_template_directory() . '/All_Custom_Post/about_us_title_cus_post.php';
require_once get_template_directory() . '/All_Custom_Post/Post_and_contact_cus_post.php';
require_once get_template_directory() . '/All_Custom_Post/Contact_info_customp_post.php';
require_once get_template_directory() . '/All_Custom_Post/footer_main_cutomPost.php';





//codingsolve search
function codingsolve_search_form() {
    $home_url    = esc_url( get_home_url( '/' ) );
    $value       = esc_attr( get_search_query() );
    $placeholder = __( 'Type here to Search....', 'codingsolvetextd' );
    $form        = <<<FORM
    <form action="{$home_url}" method="GET" class="search-popup__form">
        <input name="s" value="{$value}" type="text" placeholder="{$placeholder}" id="as_your_wish">
        <button type="submit"><i class="fa fa-search"></i></button>
    </form>
FORM;
    return $form;
}

add_action( 'get_search_form', 'codingsolve_search_form' );







// Custom post option Disabale

function disable_new_posts() {
    // Hide sidebar link
    global $submenu;
    unset($submenu['edit.php?post_type=all_why_show'][10]);

    // Hide link on listing page
    if (isset($_GET['post_type']) && $_GET['post_type'] == 'all_why_show') {
        echo '<style type="text/css">
        #favorite-actions, .add-new-h2, .tablenav { display:none; }
        </style>';
    }
}
add_action('admin_menu', 'disable_new_posts');




//start Hide page Editor

function hide_contactpagetemplate_editor() {
    if ( is_admin() ) {
        $post_id = 0;
        if(isset($_GET['post'])) $post_id = $_GET['post'];
        $template_file = get_post_meta($post_id, '_wp_page_template', TRUE);
        if ($template_file == 'contact.php') {
            remove_post_type_support('page', 'editor');
        }
    }
}
add_action( 'admin_init', 'hide_contactpagetemplate_editor' );


function hide_aboutpagetemplate_editor() {
    if ( is_admin() ) {
        $post_id = 0;
        if(isset($_GET['post'])) $post_id = $_GET['post'];
        $template_file = get_post_meta($post_id, '_wp_page_template', TRUE);
        if ($template_file == 'about.php') {
            remove_post_type_support('page', 'editor');
        }
    }
}
add_action( 'admin_init', 'hide_aboutpagetemplate_editor' );


function hide_servicepagetemplate_editor() {
    if ( is_admin() ) {
        $post_id = 0;
        if(isset($_GET['post'])) $post_id = $_GET['post'];
        $template_file = get_post_meta($post_id, '_wp_page_template', TRUE);
        if ($template_file == 'service.php') {
            remove_post_type_support('page', 'editor');
        }
    }
}
add_action( 'admin_init', 'hide_servicepagetemplate_editor' );

//End Hide page Editor








