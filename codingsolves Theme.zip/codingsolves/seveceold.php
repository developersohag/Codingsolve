         <?php  
        $args = array(  
            'post_type' => 'service_section',
             'post_status' => 'publish',
             'posts_per_page' => 1,
             );
        $service_section = new WP_Query( $args );  
            if ( $service_section->have_posts() ) : $service_section->the_post();
        ?> 
<!--Services Section-->
<section class="services-section-two">
            <div class="auto-container">
                <div class="sec-title">
                    <!--Title Block-->
                    <div class="row clearfix">
                        <div class="column col-xl-6 col-lg-12 col-md-12 col-sm-12">
                            <h2><?php echo get_the_title(); ?><span class="dot">.</span></h2>
                        </div>
                        <div class="column col-xl-6 col-lg-12 col-md-12 col-sm-12">
                            <div class="lower-text"><?php echo get_the_content(); ?></div>
                        </div>
                    </div>
                </div>
				 <div class="services">
                    <div class="row clearfix">
                        <!--Service Block-->
                         <?php 
                         $service_group	= get_post_meta(get_the_ID(),'service_section_group',true);
                         foreach ($service_group as $service_groups): 
                         	$image 	= 	wp_get_attachment_image($service_groups['service_image']['0']) ;
                         	$name 	= 	$service_groups['service_name'];
                         	$dis 	= 	$service_groups['service_des'];
                         	$url 	= 	$service_groups['url'];
                         ?>
                        <div class="service-block-two col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <div class="bottom-curve"></div>
                                <div class="icon-box"><span class="flaticon-vector_Coding"><a href="<?php the_permalink(); ?>"><?php echo $image  ;?></a></span></div>
                                <h5><a href="<?php echo $url  ;?>"><?php echo esc_html($name);?></h5>
                                <div class="text"><?php echo apply_filters('get_the_content',$dis);?></div>
                                <div class="link-box"><a href="<?php echo $url  ;?>"><span class="fa fa-angle-right"></span></a></div>
                            </div>
                        </div>
                        <?php endforeach ?>
                    </div>
                </div>               
            </div>
        </section>
        <?php endif ?>