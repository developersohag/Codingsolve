
<?php 

get_header();
?>



        <!-- Banner Section -->
        <section class="page-banner">
            <div class="image-layer" style="background-image:url(<?php echo get_the_post_thumbnail_url(); ?>);"></div>
            <div class="shape-1"></div>
            <div class="shape-2"></div>
            <div class="banner-inner">
                <div class="auto-container">
                    <div class="inner-container clearfix">
                        <h1> Your Search Result  "<?php echo get_search_query() ;?>"</h1>
                        <div class="page-nav">
                            <ul class="bread-crumb clearfix">
                                <li><a href="<?php bloginfo('url'); ?>">Home</a></li>
                                <li class="active"> <?php echo get_the_title();?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Banner Section -->
      


        <section class="news-section alt-bg" >
            <div class="auto-container">
                <div class="row clearfix"> 
                    <?php
    global $query_string;
    $query_args = explode("&", $query_string);
    $search_query = array();

    foreach($query_args as $key => $string) {
      $query_split = explode("=", $string);
      $search_query[$query_split[0]] = urldecode($query_split[1]);
    } // foreach

    $the_query = new WP_Query($search_query);
    if ( $the_query->have_posts() ) : 
    ?>
    <!-- the loop -->
<div class="news-block col-lg-12 col-md-12 col-sm-12 wow fadeInUp" data-wow-delay="300ms"
                        data-wow-duration="1500ms">
    <div class="image-box">
                             <h6>  Your Search Item hear....</h6>
                            </div> 
                                </div> 
    <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>

                    <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms"
                        data-wow-duration="1500ms">
                        <div class="inner-box">                                                       
                            <div class="lower-box">
                                <h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>

                                <div class="link-box"><a class="theme-btn" href="<?php the_permalink(); ?>"><span
                                            class="flaticon-next-1"></span></a></div>

                            </div>
                        </div>
                    </div>  
                    <?php endwhile; ?>  
    <!-- end of the loop -->

                <?php wp_reset_postdata(); ?>
            <?php else : ?>

                <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms"
                        data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="image-box">
                               <img src="https://www.codingsolve.com//demo/wp-content/themes/codingsolves/assets/images/What_do_you_mean.png"> <a href="<?php the_permalink(); ?>"><img src="<?php echo get_the_post_thumbnail_url();?>" alt=""></a>
                            </div>                            
                        </div>
                    </div>  
                    <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms"
                        data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="image-box">
                             <h6> What Do you Mean</h6>
                            </div>                            
                        </div>
                        <div class="more-box">
                    <a class="theme-btn btn-style-one" href="<?php bloginfo('url'); ?>">
                        <i class="btn-curve"></i>
                        <span class="btn-title">Back To <?php echo $home_title = get_the_title( get_option('page_on_front') ); ?></span>

                    </a>
                </div>
                    </div>  
            <?php endif; ?>
                
                 </div>
                
               
            </div>

             </section>
            
<?php get_footer();?>