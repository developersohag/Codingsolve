
<?php 

get_header();
the_post();
?>


        <!-- Banner Section -->
        <section class="page-banner">
            <div class="image-layer" style="background-image:url(<?php echo get_the_post_thumbnail_url(); ?>);"></div>
            <div class="shape-1"></div>
            <div class="shape-2"></div>
            <div class="banner-inner">
                <div class="auto-container">
                    <div class="inner-container clearfix">
                        <h1>   <?php echo wp_title( $sep = ' ', $display = true,  $seplocation = '' );?></h1>
                        <div class="page-nav">
                            <ul class="bread-crumb clearfix">
                                <li><a href="<?php bloginfo('url'); ?>">Home</a></li>
                                <li>Active Blog Is</li>
                                <li class="active"> <?php echo wp_title( $sep = ' ', $display = true,  $seplocation = '' );?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Banner Section -->


        <div class="sidebar-page-container">
            <div class="auto-container">
                <div class="row clearfix">

                    <!--Content Side-->
                    <div class="content-side col-lg-8 col-md-12 col-sm-12">
                        <div class="blog-details">
                            <!--News Block-->
                            <div class="post-details">
                                <div class="inner-box">
                                    <div class="image-box">
                                        <a href="blog-single.html"><img src="<?php echo get_the_post_thumbnail_url(); ?>" alt=""></a>
                                    </div>
                                    <div class="lower-box">
                                        <div class="post-meta">
                                            <ul class="clearfix">
                                                <li><span class="far fa-clock"></span><?php echo get_the_date(); ?></li>
                                                <li><span class="far fa-user-circle"></span> <?php the_author(); ?></li>
                                                <!-- <li><span class="far fa-comments"></span> <?php echo get_comments_number($post->ID); ?> Comments</li> -->
                                            </ul>
                                        </div>
                                        <h4><?php the_title(); ?></h4>
                                        <div class="text">
                                            <p><?php echo get_the_content(); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="info-row clearfix">

                                   
                                             <div class="tags-info"><strong>Tags:</strong> 
                                                 <?php 

                                        $post_tags = get_the_tags();
 
                                    if ( $post_tags ) {
                                        foreach( $post_tags as $tag ) { ?>
                                                <a href="#"><?php  echo $tag->name . ', ';  ?></a>
                                                 <?php 
                                           
                                            }
                                            }


                                     ?>
                                                
                                            </div>
                                           

                                   
<!-- 
                             <div class="cat-info"><strong>Category:</strong> <a href="#">Business</a>, <a
                                            href="#">Agency</a></div> -->
                                </div>
                            </div>
                        <!--     <div class="post-control-two">
                                <div class="row clearfix">
                                    <div class="control-col col-md-6 col-sm-12">
                                        <div class="control-inner">
                                            <h4><a href="#">A DEEP UNDERSTANDING OF OUR AUDIENCE</a></h4>
                                            <a href="#" class="over-link"></a>
                                        </div>
                                    </div>
                                    <div class="control-col col-md-6 col-sm-12">
                                        <div class="control-inner">
                                            <h4><a href="#">EXPERIENCES THAT CONNECT WITH PEOPLE</a></h4>
                                            <a href="#" class="over-link"></a>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                            <!--Comments Area-->
                        <!--     <div class="comments-area">
                                <div class="comments-title">
                                    <h3>2 Comments</h3>
                                </div>
                                <div class="comment-box">
                                    <div class="comment">
                                        <div class="author-thumb">
                                            <figure class="thumb"><img src="images/resource/author-7.jpg" alt="">
                                            </figure>
                                        </div>
                                        <div class="info">
                                            <div class="name">Jessica Brown</div>
                                            <div class="date">20 May, 2020 . 4:00 pm</div>
                                        </div>
                                        <div class="text">Lorem Ipsum is simply dummy free text of the available
                                            printing and typesetting been the industry standard dummy text ever sincer
                                            condimentum purus.</div>
                                        <div class="reply-btn">
                                            <a class="theme-btn btn-style-one" href="about.html">
                                                <i class="btn-curve"></i>
                                                <span class="btn-title">Reply</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div class="comment-box">
                                    <div class="comment">
                                        <div class="author-thumb">
                                            <figure class="thumb"><img src="images/resource/author-8.jpg" alt="">
                                            </figure>
                                        </div>
                                        <div class="info">
                                            <div class="name">David Martin</div>
                                            <div class="date">20 May, 2020 . 4:00 pm</div>
                                        </div>
                                        <div class="text">Lorem Ipsum is simply dummy free text of the available
                                            printing and typesetting been the industry standard dummy text ever sincer
                                            condimentum purus.</div>
                                        <div class="reply-btn">
                                            <a class="theme-btn btn-style-one" href="about.html">
                                                <i class="btn-curve"></i>
                                                <span class="btn-title">Reply</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </div> -->

                            <!--Leave Comment Form-->
                         <!--    <div class="leave-comments">
                                <div class="comments-title">
                                    <h3>Leave a comment</h3>
                                </div>
                                <div class="default-form comment-form">
                                    <form method="post" action="http://layerdrops.com/linoorhtml/contact.html">
                                        <div class="row clearfix">
                                            <div class="col-md-6 col-sm-12 form-group">
                                                <input type="text" name="username" placeholder="Your Name" required="">
                                            </div>

                                            <div class="col-md-6 col-sm-12 form-group">
                                                <input type="email" name="email" placeholder="Email Address"
                                                    required="">
                                            </div>

                                            <div class="col-md-6 col-sm-12 form-group">
                                                <input type="text" name="username" placeholder="Phone Number"
                                                    required="">
                                            </div>

                                            <div class="col-md-6 col-sm-12 form-group">
                                                <input type="text" name="username" placeholder="Subject" required="">
                                            </div>

                                            <div class="col-md-12 col-sm-12 form-group">
                                                <textarea name="message" placeholder="Your Comments"></textarea>
                                            </div>

                                            <div class="col-md-12 col-sm-12 form-group">
                                                <button type="submit" class="theme-btn btn-style-one">
                                                    <i class="btn-curve"></i>
                                                    <span class="btn-title">Submit Comment</span>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div> -->
                        </div>
                    </div>

                    <!--Sidebar Side-->
                    <div class="sidebar-side col-lg-4 col-md-12 col-sm-12">
                        <aside class="sidebar blog-sidebar">

                            <div class="sidebar-widget services">
                                <div class="widget-inner">
                                    <div class="sidebar-title">

                                        <?php  
                                        $args = array(  
                                        'post_type' => 'post',
                                        'post_status' => 'publish',
                                        'posts_per_page' => -1,
                                        );
                                        $posts = new WP_Query( $args ); ?>



                                        <h4>Latest Post</h4>
                                    </div>
                                    <ul>
                                    
                                     
                                        
                                         <?php 
                                          $slider =0;
                                         if ( $posts->have_posts() ) : while ( $posts->have_posts() ) : $posts->the_post();
                                         $slider++;
                                        ?>

                                      

                                       <li class="<?=( $slider == 2) ? 'activea' : ''?>"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></li>
                                    
                                    <?php endwhile; endif ;  wp_reset_query(); ?>
                                    </ul>
                                </div>
                            </div>
                             <?php require_once get_template_directory() . '/template-parts/common/contact_info_html.php'; ?>
                        </aside>
                    </div>
                </div>
            </div>
        </div>
        
  
        




<?php get_footer();?>