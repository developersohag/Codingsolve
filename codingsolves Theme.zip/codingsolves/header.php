<!doctype html>
<html lang="en">


<!-- Mirrored from layerdrops.com/linoorhtml/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 02 Aug 2020 14:07:33 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<head>
    <meta charset="utf-8">
    <title><?php bloginfo( 'name' );?></title>
    <!-- Stylesheets -->

    <?php wp_head();?>
</head>

<body <?php body_class();?>>
    <div class="page-wrapper">

        <!-- style switcher -->

        <!-- Preloader -->
        <!-- <div class="preloader">
            <div class="icon"></div>
        </div> -->

        <!-- Main Header -->
        <header class="main-header header-style-one">

            <!-- Header Upper -->
            <div class="header-upper">
                <div class="inner-container clearfix">
                    <!--Logo-->
                    <div class="logo-box">


                        <?php if ( has_custom_logo() ): ?>
                        <?php

    // Get Custom Logo URL
    $custom_logo_id   = get_theme_mod( 'custom_logo' );
    $custom_logo_data = wp_get_attachment_image_src( $custom_logo_id, 'full' );
    $custom_logo_url  = $custom_logo_data[0];
?>
                        <div class="logo">
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>"
                                title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                                <img src="<?php echo esc_url( $custom_logo_url ); ?>" id="thm-logo"
                                    alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"
                                    title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                            </a>
                        </div>
                        <?php else: ?>
                        <div class="site-name"><a
                                href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' );?></a></div>
                        <?php endif;?>
                    </div>
                    <div class="nav-outer clearfix">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler"><span class="icon flaticon-menu-2"></span><span
                                class="txt">Menu</span></div>

                        <!-- Main Menu -->
                        <nav class="main-menu navbar-expand-md navbar-light">

                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                <?php wp_nav_menu( array(
                                        'theme_locaton' => 'topmenu',
                                        'menu_class'    => 'navigation clearfix', // html div er id Worddpress E aro ace
                                        'depth'         => '3',
                                        'fallback_cb'   => 'WP_Bootstrap_Navwalker::fallback',
                                        'walker'        => new wp_bootstrap_navwalker(),
                                    ) );
                                ?>
                            </div>



                        </nav>


                        <!-- Html Menu  section-->
                        <!-- <nav class="main-menu navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                <ul class="navigation clearfix">
                                    <li class="current dropdown"><a href="index-2.html">Home</a>
                                        <ul>
                                            <li><a href="index-2.html">Home Style 01</a></li>
                                            <li><a href="index-3.html">Home Style 02</a></li>
                                            <li><a href="index-4.html">Home Style 03</a></li>
                                            <li><a href="one-page.html">Home One Page <span>new</span></a></li>
                                        </ul>
                                    </li>
                                    <li><a href="about.html">About Us</a></li>
                                    <li class="dropdown"><a href="team.html">Pages</a>
                                        <ul>
                                            <li><a href="team.html">Our Team</a></li>
                                            <li><a href="testimonials.html">Testimonials</a></li>
                                            <li><a href="faqs.html">FAQs</a></li>
                                            <li><a href="not-found.html">404 Page</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="services.html">Services</a>
                                        <ul>
                                            <li><a href="services.html">All Services</a></li>
                                            <li><a href="web-development.html">Website Development</a></li>
                                            <li><a href="graphic-designing.html">Graphic Designing</a></li>
                                            <li><a href="digital-marketing.html">Digital Marketing</a></li>
                                            <li><a href="seo.html">SEO & Content Writting</a></li>
                                            <li><a href="app-development.html">App Development</a></li>
                                            <li><a href="ui-designing.html">UI/UX Designing</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="portfolio.html">Portfolio</a>
                                        <ul>
                                            <li><a href="portfolio.html">Portfolio</a></li>
                                            <li><a href="portfolio-single.html">Portfolio Single 01</a></li>
                                            <li><a href="portfolio-single-2.html">Portfolio Single 02</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="blog-grid.html">Blog</a>
                                        <ul>
                                            <li><a href="blog.html">Blog Sidebar</a></li>
                                            <li><a href="blog-grid.html">Blog Grid View</a></li>
                                            <li><a href="blog-single.html">Blog Single</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="contact.html">Contact</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div> -->

                    </div>

                    <div class="other-links clearfix">
                        <!--Search Btn-->
                        <div class="search-btn">
                            <button type="button" class="theme-btn search-toggler"><span
                                    class="flaticon-loupe"></span></button>
                        </div>

                         <!--Get Quote Section-->
                 <?php  
                $args = array(  
                'post_type' => 'header_foter',
                'post_status' => 'publish',
                'posts_per_page' => 1,
                    );
                $header_foter = new WP_Query( $args ); 
                ?>
<?php if ($header_foter->have_posts() ) : $header_foter->the_post(); ?>
     <?php  $header_text = get_post_meta(get_the_ID(),"header_text",true); ?>
     <?php  $phone_number = get_post_meta(get_the_ID(),"phone_number",true); ?>
     <?php  $phone_rediract = get_post_meta(get_the_ID(),"phone_rediract",true); ?>
     






                        <div class="link-box">
                            <div class="call-us">
                                <a class="link" target="_blank" href="https://api.whatsapp.com/send?phone=+88<?php echo esc_html($phone_rediract); ?>">
                                    <?php 
                                     //   $image_ids// =// get_post_meta($post->ID, 'sec_img'); 
                                       // foreach ($image_ids as $image) {
                                        
                                            ?>
                                        <?php// } ?>  
                                    

                                    <span class="icon " ></span>
                                    <span class="sub-text"><?php echo esc_html($header_text); ?></span>
                                    <span class="number"><?php echo esc_html($phone_number); ?></span>
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                    </div>

                </div>
            </div>
            <!--End Header Upper-->

        </header>
        <!-- End Main Header -->

        <!--Mobile Menu-->
        <div class="side-menu__block">


            <div class="side-menu__block-overlay custom-cursor__overlay">
                <div class="cursor"></div>
                <div class="cursor-follower"></div>
            </div><!-- /.side-menu__block-overlay -->
            <div class="side-menu__block-inner ">
                <div class="side-menu__top justify-content-end">

                    <a href="#" class="side-menu__toggler side-menu__close-btn"><img
                            src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/close-1-1.png"
                            alt=""></a>
                </div><!-- /.side-menu__top -->


                <nav class="mobile-nav__container">
                    <!-- content is loading via js -->
                </nav>
                <div class="side-menu__sep"></div><!-- /.side-menu__sep -->
                <?php require_once get_template_directory() . '/template-parts/common/contact_infoo_html.php'; ?>
            </div><!-- /.side-menu__block-inner -->

        </div><!-- /.side-menu__block -->


        <!--Search Popup-->


        <!--Search Popup-->
        <div class="search-popup">
            <div class="search-popup__overlay custom-cursor__overlay">
                <div class="cursor"></div>
                <div class="cursor-follower"></div>
            </div><!-- /.search-popup__overlay -->
            <div class="search-popup__inner">
                <?php get_search_form();?>
            </div><!-- /.search-popup__inner -->
        </div><!-- /.search-popup -->