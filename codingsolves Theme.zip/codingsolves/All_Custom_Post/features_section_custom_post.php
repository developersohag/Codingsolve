<?php 



function codingsolve_features_section(){
	$labels = array(
		'name' 					=> __('Features Section Name','codingsolvetextd'),
		'singular_name' 		=> __('Features Section Singular','codingsolvetextd'),
		'menu_name' 			=> __('Features Section','codingsolvetextd'),
		'parent_item_colon' 	=> __('Parent Features Section','codingsolvetextd'),
		'all_items' 			=> __('All Features Section','codingsolvetextd'),
		'view_item' 			=> __('Viwe Features Section','codingsolvetextd'),
		'add_new_item'			=> __('Add New Features Section','codingsolvetextd'),
		'add_new'				=> __('Add New','codingsolvetextd'),
		'edit_item'				=> __('Edit Features Title','codingsolvetextd'),
		'update_item'			=> __('Update Features Section','codingsolvetextd'),
		'search_item'			=> __('search Features Section','codingsolvetextd'),
		'not_found'				=> __('No Features Section Found','codingsolvetextd'),
        'not_found_in_trash'	=> __('No Found Features Section In Trash','codingsolvetextd'),
        'featured_image'        => __('Background Image For Parallax', 'codingsolvetextd'),

	);
	$args = array(
		'label' 				=> __('Features Section','codingsolvetextd'),
		'descritiop' 			=> __('This is For Features Section','codingsolvetextd'),
		'labels'				=> $labels,
		'public' 				=> 	true,
		'supports' 				=> array('title','thumbnail'),
		'menu_icon'				=>	'dashicons-controls-repeat',
		'show_ui'				=> true, //ata show kora backend
		'show_in_menu'			=> true, //ata show kora menu
		'show_in_nav_menu'		=> true,
		'show_in_admin_bar'		=> true,
		'menu_position'			=> 307,
		'can_export'			=> true, 	// theme export improt hola tar shate at hobe
		'has_archive'			=> 'Features Section', 
		'exclude_from_search'	=> false, // Flase thekle serch er vetor asbe
		'capability_type'		=>'post' ,// page,arcive,post
		'publicly_queryable'	=> true,
		//'taxonomies'			=> array('category'),
		'hierarchical'			=> false,
		'rewite'				=> array(
			'with_front'		=> false // ata archive page kore
		)

	);
	register_post_type('features_section',$args);

}
add_action('init','codingsolve_features_section');
// custom post type end
//register post type start