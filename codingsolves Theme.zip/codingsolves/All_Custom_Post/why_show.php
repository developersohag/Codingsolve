<?php 



function codingsolve_why_show(){
	$labels = array(
		'name' 					=> __('Why Show Name','codingsolvetextd'),
		'singular_name' 		=> __('Why Show Singular','codingsolvetextd'),
		'menu_name' 			=> __('Why Show','codingsolvetextd'),
		'parent_item_colon' 	=> __('Parent Why Show','codingsolvetextd'),
		'all_items' 			=> __('All Why Show','codingsolvetextd'),
		'view_item' 			=> __('Viwe Why Show','codingsolvetextd'),
		'add_new_item'			=> __('Add New Why Show','codingsolvetextd'),
		'add_new'				=> __('Add New','codingsolvetextd'),
		'edit_item'				=> __('Edit Why Show','codingsolvetextd'),
		'update_item'			=> __('Update Why Show','codingsolvetextd'),
		'search_item'			=> __('search Why Show','codingsolvetextd'),
		'not_found'				=> __('No Why Show Found','codingsolvetextd'),
        'not_found_in_trash'	=> __('No Found Why Show In Trash','codingsolvetextd'),
        'featured_image'        => __('Why Show Image', 'codingsolvetextd'),

	);
	$args = array(
		'label' 				=> __('Why Show','codingsolvetextd'),
		'descritiop' 			=> __('This is For Why Show','codingsolvetextd'),
		'labels'				=> $labels,
		'public' 				=> 	true,
		'supports' 				=> array('title','thumbnail'),
		'menu_icon'				=>	'dashicons-format-video',
		'show_ui'				=> true, //ata show kora backend
		'show_in_menu'			=> true, //ata show kora menu
		'show_in_nav_menu'		=> true,
		'show_in_admin_bar'		=> true,
		'menu_position'			=> 303,
		'can_export'			=> true, 	// theme export improt hola tar shate at hobe
		'has_archive'			=> 'Why Show', 
		'exclude_from_search'	=> false, // Flase thekle serch er vetor asbe
		'capability_type'		=>'post' ,// page,arcive,post
		'publicly_queryable'	=> true,
		//'taxonomies'			=> array('category'),
		'hierarchical'			=> false,
		'rewite'				=> array(
			'with_front'		=> false // ata archive page kore
		)

	);
	register_post_type('all_why_show',$args);

}
add_action('init','codingsolve_why_show');
// custom post type end
//register post type start