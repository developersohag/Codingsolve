<?php 



function codingsolve_company_logo(){
	$labels = array(
		'name' 					=> __('Company Logo Name','codingsolvetextd'),
		'singular_name' 		=> __('Company Logo Singular','codingsolvetextd'),
		'menu_name' 			=> __('Company Logo','codingsolvetextd'),
		'parent_item_colon' 	=> __('Parent Company Logo','codingsolvetextd'),
		'all_items' 			=> __('All Company Logo','codingsolvetextd'),
		'view_item' 			=> __('Viwe Company Logo','codingsolvetextd'),
		'add_new_item'			=> __('Add New Company Logo','codingsolvetextd'),
		'add_new'				=> __('Add New','codingsolvetextd'),
		'edit_item'				=> __('Edit Company Logo','codingsolvetextd'),
		'update_item'			=> __('Update Company Logo','codingsolvetextd'),
		'search_item'			=> __('search Company Logo','codingsolvetextd'),
		'not_found'				=> __('No Company Logo Found','codingsolvetextd'),
        'not_found_in_trash'	=> __('No Found Company Logo In Trash','codingsolvetextd'),
        'featured_image'        => __('Company Logo Image', 'codingsolvetextd'),

	);
	$args = array(
		'label' 				=> __('Company Logo','codingsolvetextd'),
		'descritiop' 			=> __('This is For Company Logo','codingsolvetextd'),
		'labels'				=> $labels,
		'public' 				=> 	true,
		'supports' 				=> array('title'),
		'menu_icon'				=>	'dashicons-image-filter',
		'show_ui'				=> true, //ata show kora backend
		'show_in_menu'			=> true, //ata show kora menu
		'show_in_nav_menu'		=> true,
		'show_in_admin_bar'		=> true,
		'menu_position'			=> 308,
		'can_export'			=> true, 	// theme export improt hola tar shate at hobe
		'has_archive'			=> 'Company Logo', 
		'exclude_from_search'	=> false, // Flase thekle serch er vetor asbe
		'capability_type'		=>'post' ,// page,arcive,post
		'publicly_queryable'	=> true,
		//'taxonomies'			=> array('category'),
		'hierarchical'			=> false,
		'rewite'				=> array(
			'with_front'		=> false // ata archive page kore
		)

	);
	register_post_type('company_logo',$args);

}
add_action('init','codingsolve_company_logo');
// custom post type end
//register post type start