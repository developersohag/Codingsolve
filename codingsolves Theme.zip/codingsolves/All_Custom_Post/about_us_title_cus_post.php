<?php 



function codingsolve_aboutUsTitle(){
	$labels = array(
		'name' 					=> __('About Us Title Name','codingsolvetextd'),
		'singular_name' 		=> __('About Us Title Singular','codingsolvetextd'),
		'menu_name' 			=> __('About Us Title','codingsolvetextd'),
		'parent_item_colon' 	=> __('Parent About Us Title','codingsolvetextd'),
		'all_items' 			=> __('All About Us Title','codingsolvetextd'),
		'view_item' 			=> __('Viwe About Us Title','codingsolvetextd'),
		'add_new_item'			=> __('Add New About Us Title','codingsolvetextd'),
		'add_new'				=> __('Add New','codingsolvetextd'),
		'edit_item'				=> __('Edit About Us Title','codingsolvetextd'),
		'update_item'			=> __('Update About Us Title','codingsolvetextd'),
		'search_item'			=> __('search About Us Title','codingsolvetextd'),
		'not_found'				=> __('No About Us Title Found','codingsolvetextd'),
        'not_found_in_trash'	=> __('No Found About Us Title In Trash','codingsolvetextd'),
        'featured_image'        => __('About Us Title Image', 'codingsolvetextd'),

	);
	$args = array(
		'label' 				=> __('About Us Title','codingsolvetextd'),
		'descritiop' 			=> __('This is For About Us Title','codingsolvetextd'),
		'labels'				=> $labels,
		'public' 				=> 	true,
		'supports' 				=> array('title'),
		'menu_icon'				=>	'dashicons-editor-spellcheck',
		'supports' 				=> array('title','editor'),
		'show_ui'				=> true, //ata show kora backend
		'show_in_menu'			=> true, //ata show kora menu
		'show_in_nav_menu'		=> true,
		'show_in_admin_bar'		=> true,
		'menu_position'		=> 311,
		'can_export'			=> true, 	// theme export improt hola tar shate at hobe
		'has_archive'			=> 'About Us Title', 
		'exclude_from_search'	=> false, // Flase thekle serch er vetor asbe
		'capability_type'		=>'post' ,// page,arcive,post
		'publicly_queryable'	=> true,
		//'taxonomies'			=> array('category'),
		'hierarchical'			=> false,
		'rewite'				=> array(
			'with_front'		=> false // ata archive page kore
		)

	);
	register_post_type('aboutUs_Title',$args);

}
add_action('init','codingsolve_aboutUsTitle');
// custom post type end
//register post type start