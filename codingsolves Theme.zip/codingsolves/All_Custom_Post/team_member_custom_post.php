<?php 



function codingsolve_team_member(){
	$labels = array(
		'name' 					=> __('Team Member Name','codingsolvetextd'),
		'singular_name' 		=> __('Team Member Singular','codingsolvetextd'),
		'menu_name' 			=> __('Our Team Member','codingsolvetextd'),
		'parent_item_colon' 	=> __('Parent Team Member','codingsolvetextd'),
		'all_items' 			=> __('All Team Member','codingsolvetextd'),
		'view_item' 			=> __('Viwe Team Member','codingsolvetextd'),
		'add_new_item'			=> __('Add New Team Member','codingsolvetextd'),
		'add_new'				=> __('Add New','codingsolvetextd'),
		'edit_item'				=> __('Edit Team Member','codingsolvetextd'),
		'update_item'			=> __('Update Team Member','codingsolvetextd'),
		'search_item'			=> __('search Team Member','codingsolvetextd'),
		'not_found'				=> __('No Team Member Found','codingsolvetextd'),
        'not_found_in_trash'	=> __('No Found Team Member In Trash','codingsolvetextd'),
        'featured_image'        => __('Team Member Image', 'codingsolvetextd'),

	);
	$args = array(
		'label' 				=> __('Team Member','codingsolvetextd'),
		'descritiop' 			=> __('This is For Team Member','codingsolvetextd'),
		'labels'				=> $labels,
		'public' 				=> 	true,
		'supports' 				=> array('title'),
		'menu_icon'				=>	'dashicons-universal-access',
		'show_ui'				=> true, //ata show kora backend
		'show_in_menu'			=> true, //ata show kora menu
		'show_in_nav_menu'		=> true,
		'show_in_admin_bar'		=> true,
		'menu_position'		=> 310,
		'can_export'			=> true, 	// theme export improt hola tar shate at hobe
		'has_archive'			=> 'Team Member', 
		'exclude_from_search'	=> false, // Flase thekle serch er vetor asbe
		'capability_type'		=>'post' ,// page,arcive,post
		'publicly_queryable'	=> true,
		//'taxonomies'			=> array('category'),
		'hierarchical'			=> false,
		'rewite'				=> array(
			'with_front'		=> false // ata archive page kore
		)

	);
	register_post_type('all_team_member',$args);

}
add_action('init','codingsolve_team_member');
// custom post type end
//register post type start