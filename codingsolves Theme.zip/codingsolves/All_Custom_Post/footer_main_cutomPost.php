<?php 



function footer_main(){
	$labels = array(
		'name' 					=> __('Main Footer Name','codingsolvetextd'),
		'singular_name' 		=> __('Main Footer Singular','codingsolvetextd'),
		'menu_name' 			=> __('Main Footer','codingsolvetextd'),
		'parent_item_colon' 	=> __('Parent Main Footer','codingsolvetextd'),
		'all_items' 			=> __('Main Footer Form','codingsolvetextd'),
		'view_item' 			=> __('Viwe Main Footer','codingsolvetextd'),
		'add_new_item'			=> __('Add New Main Footer','codingsolvetextd'),
		'add_new'				=> __('Add New','codingsolvetextd'),
		'edit_item'				=> __('Edit Main Footer','codingsolvetextd'),
		'update_item'			=> __('Update Main Footer','codingsolvetextd'),
		'search_item'			=> __('search Main Footer','codingsolvetextd'),
		'not_found'				=> __('No Main Footer Found','codingsolvetextd'),
        'not_found_in_trash'	=> __('No Found Main Footer In Trash','codingsolvetextd'),
        'featured_image'        => __('1st Colum Logo', 'codingsolvetextd'),

	);
	$args = array(
		'label' 				=> __('Main Footer','codingsolvetextd'),
		'descritiop' 			=> __('This is For Main Footer','codingsolvetextd'),
		'labels'				=> $labels,
		'public' 				=> 	true,
		'supports' 				=> array('title'),
		'menu_icon'				=>	'dashicons-welcome-add-page',
		'supports' 				=> array('thumbnail'),
		'show_ui'				=> true, //ata show kora backend
		'show_in_menu'			=> true, //ata show kora menu
		'show_in_nav_menu'		=> true,
		'show_in_admin_bar'		=> true,
		'menu_position'			=> 316,
		'can_export'			=> true, 	// theme export improt hola tar shate at hobe
		'has_archive'			=> 'Main Footer', 
		'exclude_from_search'	=> false, // Flase thekle serch er vetor asbe
		'capability_type'		=>'post' ,// page,arcive,post
		'publicly_queryable'	=> true,
		//'taxonomies'			=> array('category'),
		'hierarchical'			=> false,
		'rewite'				=> array(
			'with_front'		=> false // ata archive page kore
		)

	);
	register_post_type('footer_main',$args);

}
add_action('init','footer_main');
// custom post type end
//register post type start