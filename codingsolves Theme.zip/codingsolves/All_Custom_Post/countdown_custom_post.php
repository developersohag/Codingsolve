<?php 



function codingsolve_count_down(){
	$labels = array(
		'name' 					=> __('Count Down Name','codingsolvetextd'),
		'singular_name' 		=> __('Count Down Singular','codingsolvetextd'),
		'menu_name' 			=> __('Count Down Header','codingsolvetextd'),
		'parent_item_colon' 	=> __('Parent Count Down','codingsolvetextd'),
		'all_items' 			=> __('All Count Down','codingsolvetextd'),
		'view_item' 			=> __('Viwe Count Down','codingsolvetextd'),
		'add_new_item'			=> __('Add New Count Down','codingsolvetextd'),
		'add_new'				=> __('Add New','codingsolvetextd'),
		'edit_item'				=> __('Edit Count Down','codingsolvetextd'),
		'update_item'			=> __('Update Count Down','codingsolvetextd'),
		'search_item'			=> __('search Count Down','codingsolvetextd'),
		'not_found'				=> __('No Count Down Found','codingsolvetextd'),
        'not_found_in_trash'	=> __('No Found Count Down In Trash','codingsolvetextd'),
        'featured_image'        => __('Count Down Image', 'codingsolvetextd'),

	);
	$args = array(
		'label' 				=> __('Count Down','codingsolvetextd'),
		'descritiop' 			=> __('This is For Count Down','codingsolvetextd'),
		'labels'				=> $labels,
		'public' 				=> 	true,
		'supports' 				=> array('title','editor','thumbnail','excerpt','comments','rivisions','custom-fields'),
		'menu_icon'				=>	'dashicons-backup',
		'show_ui'				=> true, //ata show kora backend
		'show_in_menu'			=> true, //ata show kora menu
		'show_in_nav_menu'		=> true,
		'show_in_admin_bar'		=> true,
		'menu_position'			=> 301,
		'can_export'			=> true, 	// theme export improt hola tar shate at hobe
		'has_archive'			=> 'Count Down', 
		'exclude_from_search'	=> false, // Flase thekle serch er vetor asbe
		'capability_type'		=>'post' ,// page,arcive,post
		'publicly_queryable'	=> true,
		//'taxonomies'			=> array('category'),
		'hierarchical'			=> false,
		'rewite'				=> array(
			'with_front'		=> false // ata archive page kore
		)

	);
	register_post_type('count_down',$args);

}
add_action('init','codingsolve_count_down');
// custom post type end
//register post type start