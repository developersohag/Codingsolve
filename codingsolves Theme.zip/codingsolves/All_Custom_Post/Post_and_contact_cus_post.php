<?php 



function post_and_contact(){
	$labels = array(
		'name' 					=> __('Post And Contact Name','codingsolvetextd'),
		'singular_name' 		=> __('Post And Contact Singular','codingsolvetextd'),
		'menu_name' 			=> __('Post And Contact','codingsolvetextd'),
		'parent_item_colon' 	=> __('Parent Post And Contact','codingsolvetextd'),
		'all_items' 			=> __('Post And Contact Form','codingsolvetextd'),
		'view_item' 			=> __('Viwe Post And Contact','codingsolvetextd'),
		'add_new_item'			=> __('Add New Post And Contact','codingsolvetextd'),
		'add_new'				=> __('Add New','codingsolvetextd'),
		'edit_item'				=> __('Edit Post And Contact','codingsolvetextd'),
		'update_item'			=> __('Update Post And Contact','codingsolvetextd'),
		'search_item'			=> __('search Post And Contact','codingsolvetextd'),
		'not_found'				=> __('No Post And Contact Found','codingsolvetextd'),
        'not_found_in_trash'	=> __('No Found Post And Contact In Trash','codingsolvetextd'),
        'featured_image'        => __('Post And Contact Image', 'codingsolvetextd'),

	);
	$args = array(
		'label' 				=> __('Post And Contact','codingsolvetextd'),
		'descritiop' 			=> __('This is For Post And Contact','codingsolvetextd'),
		'labels'				=> $labels,
		'public' 				=> 	true,
		'supports' 				=> array('title'),
		'menu_icon'				=>	'dashicons-welcome-add-page',
		'supports' 				=> array('title','editor','thumbnail'),
		'show_ui'				=> true, //ata show kora backend
		'show_in_menu'			=> true, //ata show kora menu
		'show_in_nav_menu'		=> true,
		'show_in_admin_bar'		=> true,
		'menu_position'			=> 307,
		'can_export'			=> true, 	// theme export improt hola tar shate at hobe
		'has_archive'			=> 'Post And Contact', 
		'exclude_from_search'	=> false, // Flase thekle serch er vetor asbe
		'capability_type'		=>'post' ,// page,arcive,post
		'publicly_queryable'	=> true,
		//'taxonomies'			=> array('category'),
		'hierarchical'			=> false,
		'rewite'				=> array(
			'with_front'		=> false // ata archive page kore
		)

	);
	register_post_type('post_and_contact',$args);

}
add_action('init','post_and_contact');
// custom post type end
//register post type start