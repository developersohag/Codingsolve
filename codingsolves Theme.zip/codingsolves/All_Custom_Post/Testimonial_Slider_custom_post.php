<?php 



function codingsolvetextd_Feedback_slider(){
	$labels = array(
		'name' 					=> __('Testimonial Slider Name','codingsolvetextd'),
		'singular_name' 		=> __('Testimonial Slider Singular','codingsolvetextd'),
		'menu_name' 			=> __('Testimonial Slider','codingsolvetextd'),
		'parent_item_colon' 	=> __('Parent Testimonial Slider','codingsolvetextd'),
		'all_items' 			=> __('All Testimonial Slider','codingsolvetextd'),
		'view_item' 			=> __('Viwe Testimonial Slider','codingsolvetextd'),
		'add_new_item'			=> __('Add New Testimonial Slider','codingsolvetextd'),
		'add_new'				=> __('Add New','codingsolvetextd'),
		'edit_item'				=> __('Edit Testimonial Slider','codingsolvetextd'),
		'update_item'			=> __('Update Testimonial Slider','codingsolvetextd'),
		'search_item'			=> __('search Testimonial Slider','codingsolvetextd'),
		'not_found'				=> __('No Testimonial Slider Found','codingsolvetextd'),
        'not_found_in_trash'	=> __('No Found Testimonial Slider In Trash','codingsolvetextd'),
        'featured_image'        => __('Testimonial Slider Image', 'codingsolvetextd'),

	);
	$args = array(
		'label' 				=> __('Testimonial Slider','codingsolvetextd'),
		'descritiop' 			=> __('This is For Testimonial Slider','codingsolvetextd'),
		'labels'				=> $labels,
		'public' 				=> 	true,
		'supports' 				=> array('title','editor','thumbnail',),
		'menu_icon'				=>	'dashicons-images-alt',
		'show_ui'				=> true, //ata show kora backend
		'show_in_menu'			=> true, //ata show kora menu
		'show_in_nav_menu'		=> true,
		'show_in_admin_bar'		=> true,
		'menu_position'			=> 306,
		'can_export'			=> true, 	// theme export improt hola tar shate at hobe
		'has_archive'			=> 'Testimonial Slider', 
		'exclude_from_search'	=> false, // Flase thekle serch er vetor asbe
		'capability_type'		=>'post' ,// page,arcive,post
		'publicly_queryable'	=> true,
		//'taxonomies'			=> array('category'),
		'hierarchical'			=> false,
		'rewite'				=> array(
			'with_front'		=> false // ata archive page kore
		)

	);
	register_post_type('feedback_slider',$args);

}
add_action('init','codingsolvetextd_Feedback_slider');
// custom post type end
//register post type start