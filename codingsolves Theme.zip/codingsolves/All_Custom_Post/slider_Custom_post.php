<?php 



function codingsolvetextd_custom_post(){
	$labels = array(
		'name' 					=> __('Slider Name','codingsolvetextd'),
		'singular_name' 		=> __('Slider Singular','codingsolvetextd'),
		'menu_name' 			=> __('Slider Header','codingsolvetextd'),
		'parent_item_colon' 	=> __('Parent Slider','codingsolvetextd'),
		'all_items' 			=> __('All Slider','codingsolvetextd'),
		'view_item' 			=> __('Viwe Slider','codingsolvetextd'),
		'add_new_item'			=> __('Add New Slider','codingsolvetextd'),
		'add_new'				=> __('Add New','codingsolvetextd'),
		'edit_item'				=> __('Edit Slider','codingsolvetextd'),
		'update_item'			=> __('Update Slider','codingsolvetextd'),
		'search_item'			=> __('search Slider','codingsolvetextd'),
		'not_found'				=> __('No Slider Found','codingsolvetextd'),
        'not_found_in_trash'	=> __('No Found Slider In Trash','codingsolvetextd'),
        'featured_image'        => __('Slider Image', 'codingsolvetextd'),

	);
	$args = array(
		'label' 				=> __('slider','codingsolvetextd'),
		'descritiop' 			=> __('This is For Slider','codingsolvetextd'),
		'labels'				=> $labels,
		'public' 				=> 	true,
		'supports' 				=> array('title','editor','thumbnail',),
		'menu_icon'				=>	'dashicons-welcome-view-site',
		'show_ui'				=> true, //ata show kora backend
		'show_in_menu'			=> true, //ata show kora menu
		'show_in_nav_menu'		=> true,
		'show_in_admin_bar'		=> true,
		'menu_position'			=> 300,
		'can_export'			=> true, 	// theme export improt hola tar shate at hobe
		'has_archive'			=> 'slider', 
		'exclude_from_search'	=> false, // Flase thekle serch er vetor asbe
		'capability_type'		=>'post' ,// page,arcive,post
		'publicly_queryable'	=> true,
		//'taxonomies'			=> array('category'),
		'hierarchical'			=> false,
		'rewite'				=> array(
			'with_front'		=> false // ata archive page kore
		)

	);
	register_post_type('header_slider',$args);

}
add_action('init','codingsolvetextd_custom_post');
// custom post type end
//register post type start