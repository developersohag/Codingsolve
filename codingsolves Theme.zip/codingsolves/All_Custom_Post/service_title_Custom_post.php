<?php 



function codingsolvetextd_serive_title(){
	$labels = array(
		'name' 					=> __('Servive Title & Sub Name','codingsolvetextd'),
		'singular_name' 		=> __('Servive Title & Sub Singular','codingsolvetextd'),
		'menu_name' 			=> __('Servive Title & Sub','codingsolvetextd'),
		'parent_item_colon' 	=> __('Parent Servive Title & Sub','codingsolvetextd'),
		'all_items' 			=> __('All Servive Title & Sub','codingsolvetextd'),
		'view_item' 			=> __('Viwe Servive Title & Sub','codingsolvetextd'),
		'add_new_item'			=> __('Add New Servive Title & Sub','codingsolvetextd'),
		'add_new'				=> __('Add New','codingsolvetextd'),
		'edit_item'				=> __('Edit Servive Title & Sub','codingsolvetextd'),
		'update_item'			=> __('Update Servive Title & Sub','codingsolvetextd'),
		'search_item'			=> __('search Servive Title & Sub','codingsolvetextd'),
		'not_found'				=> __('No Servive Title & Sub Found','codingsolvetextd'),
        'not_found_in_trash'	=> __('No Found Servive Title & Sub In Trash','codingsolvetextd'),
        'featured_image'        => __('Servive Title & Sub Image', 'codingsolvetextd'),

	);
	$args = array(
		'label' 				=> __('Servive Title & Sub','codingsolvetextd'),
		'descritiop' 			=> __('This is For Servive Title & Sub','codingsolvetextd'),
		'labels'				=> $labels,
		'public' 				=> 	true,
		'supports' 				=> array('title','editor'),
		'menu_icon'				=>	'dashicons-editor-spellcheck',
		'show_ui'				=> true, //ata show kora backend
		'show_in_menu'			=> true, //ata show kora menu
		'show_in_nav_menu'		=> true,
		'show_in_admin_bar'		=> true,
		'menu_position'			=> 302,
		'can_export'			=> true, 	// theme export improt hola tar shate at hobe
		'has_archive'			=> 'Servive Title & Sub', 
		'exclude_from_search'	=> false, // Flase thekle serch er vetor asbe
		'capability_type'		=>'post' ,// page,arcive,post
		'publicly_queryable'	=> true,
		//'taxonomies'			=> array('category'),
		'hierarchical'			=> false,
		'rewite'				=> array(
			'with_front'		=> false // ata archive page kore
		)

	);
	register_post_type('service_title',$args);

}
add_action('init','codingsolvetextd_serive_title');
// custom post type end
//register post type start