<?php 



function codingsolve_header_footer(){
	$labels = array(
		'name' 					=> __('Contact info Name','codingsolvetextd'),
		'singular_name' 		=> __('Contact info Singular','codingsolvetextd'),
		'menu_name' 			=> __('Contact info & Footer Top','codingsolvetextd'),
		'parent_item_colon' 	=> __('Parent Contact info','codingsolvetextd'),
		'all_items' 			=> __('All Contact info','codingsolvetextd'),
		'view_item' 			=> __('Viwe Contact info','codingsolvetextd'),
		'add_new_item'			=> __('Add New Contact info','codingsolvetextd'),
		'add_new'				=> __('Add New','codingsolvetextd'),
		'edit_item'				=> __('Edit Contact info Footer Top Title','codingsolvetextd'),
		'update_item'			=> __('Update Contact info','codingsolvetextd'),
		'search_item'			=> __('search Contact info','codingsolvetextd'),
		'not_found'				=> __('No Contact info Found','codingsolvetextd'),
        'not_found_in_trash'	=> __('No Found Contact info In Trash','codingsolvetextd'),
        'featured_image'        => __('Contact info Image', 'codingsolvetextd'),

	);
	$args = array(
		'label' 				=> __('Contact info','codingsolvetextd'),
		'descritiop' 			=> __('This is For Contact info','codingsolvetextd'),
		'labels'				=> $labels,
		'public' 				=> 	true,
		'supports' 				=> array('title'),
		'menu_icon'				=>	'dashicons-editor-contract',
		'supports' 				=> array('title'),
		'show_ui'				=> true, //ata show kora backend
		'show_in_menu'			=> true, //ata show kora menu
		'show_in_nav_menu'		=> true,
		'show_in_admin_bar'		=> true,
		'menu_position'			=> 315,
		'can_export'			=> true, 	// theme export improt hola tar shate at hobe
		'has_archive'			=> 'Contact info', 
		'exclude_from_search'	=> false, // Flase thekle serch er vetor asbe
		'capability_type'		=>'post' ,// page,arcive,post
		'publicly_queryable'	=> true,
		//'taxonomies'			=> array('category'),
		'hierarchical'			=> false,
		'rewite'				=> array(
			'with_front'		=> false // ata archive page kore
		)

	);
	register_post_type('header_foter',$args);

}
add_action('init','codingsolve_header_footer');
// custom post type end
//register post type start